"""
app.py  —  Flask server for C Code Optimizer
Run:  python app.py
Open: http://127.0.0.1:5000
"""

from flask import Flask, request, jsonify, render_template
from optimizer_engine import run_optimizer

app = Flask(__name__)


# ══════════════════════════════════════════════════════
#  ROUTES
# ══════════════════════════════════════════════════════

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/optimize', methods=['POST'])
def optimize():
    try:
        data = request.get_json()
        if not data or 'code' not in data:
            return jsonify({"error": "No code provided"}), 400

        result = run_optimizer(data['code'])
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    print("\n" + "="*50)
    print("  C Code Optimizer — Compiler Design Project")
    print("  Techniques: CF | DCE | LICM")
    print("="*50)
    print("  Server: http://127.0.0.1:5000")
    print("  Stop:   Ctrl+C")
    print("="*50 + "\n")
    app.run(debug=True, port=5000)
