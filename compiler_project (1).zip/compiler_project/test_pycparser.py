import sys
from pycparser import c_parser, c_ast, c_generator

code = """
int main() {
    int a = 3 + 5;
    int b = a * 2;
    if (b > 10) {
        return 1;
    }
    return 0;
}
"""

parser = c_parser.CParser()
ast = parser.parse(code)
print("AST parsed successfully!")

generator = c_generator.CGenerator()
generated = generator.visit(ast)
print("Generated Code:")
print(generated)
