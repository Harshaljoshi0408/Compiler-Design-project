"""
test_dead_code.py — Edge-case tests for Dead Code Elimination
Tests: unreachable code, unused variables, overwritten values, always-false conditions
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from optimizer.dead_code_elimination import (
    find_unreachable_code,
    find_unused_variables,
    find_overwritten_values,
    find_always_false_conditions,
    dead_code_elimination,
)


def to_lines(code: str):
    """Convert code string to list of lines with newlines."""
    lines = code.split('\n')
    return [line + '\n' for line in lines]


class TestUnreachableCode(unittest.TestCase):
    """Test code after return/break/continue/goto/exit."""

    def test_code_after_return(self):
        code = """int test() {
    return 5;
    int x = 10;
}"""
        lines = to_lines(code)
        result, steps = find_unreachable_code(lines)
        self.assertTrue(any(s['tag'] == 'DCE-UCE' for s in steps))

    def test_code_after_break(self):
        code = """void test() {
    while (1) {
        break;
        x = 10;
    }
}"""
        lines = to_lines(code)
        result, steps = find_unreachable_code(lines)
        self.assertTrue(any(s['tag'] == 'DCE-UCE' for s in steps))

    def test_code_after_continue(self):
        code = """void test() {
    while (1) {
        continue;
        x = 10;
    }
}"""
        lines = to_lines(code)
        result, steps = find_unreachable_code(lines)
        self.assertTrue(any(s['tag'] == 'DCE-UCE' for s in steps))

    def test_code_after_exit(self):
        code = """void test() {
    exit(0);
    printf("dead");
}"""
        lines = to_lines(code)
        result, steps = find_unreachable_code(lines)
        self.assertTrue(any(s['tag'] == 'DCE-UCE' for s in steps))

    def test_else_after_return_not_dead(self):
        """Code in else branch after if-return should NOT be dead."""
        code = """int test(int x) {
    if (x > 0) {
        return 1;
    } else {
        return 0;
    }
}"""
        lines = to_lines(code)
        result, steps = find_unreachable_code(lines)
        # The else block should NOT be marked as dead
        for s in steps:
            self.assertNotIn("return 0", s.get("before", ""))

    def test_no_dead_code(self):
        code = """int test() {
    int x = 5;
    return x;
}"""
        lines = to_lines(code)
        result, steps = find_unreachable_code(lines)
        self.assertEqual(len(steps), 0)

    def test_nested_return(self):
        code = """int test() {
    if (1) {
        return 1;
        printf("dead");
    }
    return 0;
}"""
        lines = to_lines(code)
        result, steps = find_unreachable_code(lines)
        self.assertTrue(any(s['tag'] == 'DCE-UCE' for s in steps))


class TestUnusedVariables(unittest.TestCase):
    """Test unused variable detection."""

    def test_basic_unused(self):
        code = """int test() {
    int unused = 42;
    return 0;
}"""
        lines = to_lines(code)
        result, steps = find_unused_variables(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("unused", steps[0]["before"])

    def test_used_variable_not_removed(self):
        code = """int test() {
    int used = 10;
    return used;
}"""
        lines = to_lines(code)
        result, steps = find_unused_variables(lines)
        self.assertEqual(len(steps), 0, "Used variable should not be removed")

    def test_variable_used_in_printf(self):
        code = """void test() {
    int x = 5;
    printf("%d", x);
}"""
        lines = to_lines(code)
        result, steps = find_unused_variables(lines)
        self.assertEqual(len(steps), 0, "Variable used in printf should not be removed")

    def test_for_loop_variable_not_removed(self):
        """For-loop iterator variable should NOT be detected as unused."""
        code = """void test() {
    for (int i = 0; i < 10; i++) {
        printf("%d", i);
    }
}"""
        lines = to_lines(code)
        result, steps = find_unused_variables(lines)
        self.assertEqual(len(steps), 0, "Loop variable should not be removed")

    def test_multiple_unused(self):
        code = """int test() {
    int a = 1;
    int b = 2;
    float c = 3.14;
    return 0;
}"""
        lines = to_lines(code)
        result, steps = find_unused_variables(lines)
        self.assertEqual(len(steps), 3)

    def test_variable_used_in_condition(self):
        code = """int test() {
    int x = 5;
    if (x > 0) {
        return 1;
    }
    return 0;
}"""
        lines = to_lines(code)
        result, steps = find_unused_variables(lines)
        self.assertEqual(len(steps), 0)


class TestOverwrittenValues(unittest.TestCase):
    """Test dead store detection."""

    def test_simple_overwrite(self):
        code = """void test() {
    int x = 5;
    x = 10;
    printf("%d", x);
}"""
        lines = to_lines(code)
        result, steps = find_overwritten_values(lines)
        self.assertEqual(len(steps), 1)

    def test_read_before_overwrite_not_dead(self):
        code = """void test() {
    int x = 5;
    printf("%d", x);
    x = 10;
}"""
        lines = to_lines(code)
        result, steps = find_overwritten_values(lines)
        self.assertEqual(len(steps), 0)

    def test_compound_assignment_reads(self):
        """x += 1 reads x, so previous assignment is not dead."""
        code = """void test() {
    int x = 5;
    x += 1;
}"""
        lines = to_lines(code)
        result, steps = find_overwritten_values(lines)
        self.assertEqual(len(steps), 0)

    def test_self_reference_not_dead(self):
        """x = x + 1 reads x, so previous assignment is not dead."""
        code = """void test() {
    int x = 5;
    x = x + 1;
    printf("%d", x);
}"""
        lines = to_lines(code)
        result, steps = find_overwritten_values(lines)
        self.assertEqual(len(steps), 0)

    def test_increment_reads(self):
        """x++ reads x, so previous assignment is not dead."""
        code = """void test() {
    int x = 5;
    x++;
}"""
        lines = to_lines(code)
        result, steps = find_overwritten_values(lines)
        self.assertEqual(len(steps), 0)

    def test_no_overwrite(self):
        code = """void test() {
    int x = 5;
    printf("%d", x);
}"""
        lines = to_lines(code)
        result, steps = find_overwritten_values(lines)
        self.assertEqual(len(steps), 0)


class TestAlwaysFalseConditions(unittest.TestCase):
    """Test always-false/true condition detection."""

    def test_always_false_if(self):
        code = """void test() {
    if (0 > 1) {
        printf("dead");
    }
}"""
        lines = to_lines(code)
        result, steps = find_always_false_conditions(lines)
        self.assertTrue(any(s['tag'] == 'DCE-AFC' for s in steps))

    def test_always_true_else_dead(self):
        """Test that else block is dead when if condition is always true.
        Note: This is tested via the full pipeline since always-true detection
        requires CF to fold the condition first, and } else { on same line
        is a known limitation of standalone find_always_false_conditions.
        """
        code = """void test() {
    if (5 == 5) {
        printf("alive");
    }
    if (0 > 1) {
        printf("dead false branch");
    }
}"""
        lines = to_lines(code)
        # Test that always-false condition IS detected
        result, steps = find_always_false_conditions(lines)
        afc_steps = [s for s in steps if s['tag'] == 'DCE-AFC']
        self.assertTrue(len(afc_steps) > 0, "Should detect always-false condition")

    def test_variable_condition_not_eliminated(self):
        """Conditions with variables should not be eliminated."""
        code = """void test(int x) {
    if (x > 0) {
        printf("alive");
    }
}"""
        lines = to_lines(code)
        result, steps = find_always_false_conditions(lines)
        self.assertEqual(len(steps), 0)

    def test_while_false(self):
        code = """void test() {
    while (1 > 5) {
        printf("dead");
    }
}"""
        lines = to_lines(code)
        result, steps = find_always_false_conditions(lines)
        self.assertTrue(any(s['tag'] == 'DCE-AFC' for s in steps))


class TestFullDCE(unittest.TestCase):
    """Integration test for all DCE sub-techniques together."""

    def test_all_techniques_together(self):
        code = """int test() {
    int unused = 42;
    int temp = 5;
    temp = 10;
    
    if (0 > 1) {
        printf("Never");
    }
    
    return 0;
    printf("Dead");
}"""
        lines = to_lines(code)
        result, steps = dead_code_elimination(lines)
        tags = [s['tag'] for s in steps]
        # Should have at least one of each type
        self.assertTrue('DCE-UCE' in tags, "Should find unreachable code")
        self.assertTrue('DCE-UVE' in tags, "Should find unused variable")

    def test_empty_function(self):
        code = """void test() {
}"""
        lines = to_lines(code)
        result, steps = dead_code_elimination(lines)
        self.assertEqual(len(steps), 0)

    def test_only_comments(self):
        code = """// This is a comment
// Another comment"""
        lines = to_lines(code)
        result, steps = dead_code_elimination(lines)
        self.assertEqual(len(steps), 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
