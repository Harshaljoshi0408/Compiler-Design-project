"""
test_constant_folding.py — Edge-case tests for Constant Folding
Tests: simple folds, false-positive prevention, operator order, array init, conditions
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from optimizer.constant_folding import constant_folding


class TestNoFalseFolding(unittest.TestCase):
    """Bug 1: Single-literal values should NOT be reported as optimized."""

    def test_return_zero_no_fold(self):
        lines = ["    return 0;\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 0, "return 0; should NOT be folded")

    def test_return_literal_no_fold(self):
        lines = ["    return 42;\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 0, "return 42; should NOT be folded")

    def test_int_single_value_no_fold(self):
        lines = ["    int x = 10;\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 0, "int x = 10; is already a literal")

    def test_float_single_value_no_fold(self):
        lines = ["    float f = 3.14;\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 0, "float f = 3.14; is already a literal")

    def test_assignment_single_value_no_fold(self):
        lines = ["    x = 0;\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 0, "x = 0; is already a literal")


class TestSimpleFolding(unittest.TestCase):
    """Test basic arithmetic folding."""

    def test_simple_addition(self):
        lines = ["    int x = 3 + 5;\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("8", result[0])
        self.assertEqual(steps[0]["tag"], "CF-SIMPLE")

    def test_simple_subtraction(self):
        lines = ["    int x = 10 - 3;\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("7", result[0])

    def test_return_expression(self):
        lines = ["    return 3 + 5;\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("8", result[0])


class TestMixedFolding(unittest.TestCase):
    """Test complex expressions with parentheses."""

    def test_parenthesized(self):
        lines = ["    int x = (3 + 5) * 2;\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("16", result[0])
        self.assertEqual(steps[0]["tag"], "CF-MIXED")

    def test_division_with_addition(self):
        lines = ["    int x = 100 / 4 + 5;\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("30", result[0])

    def test_deeply_nested_parens(self):
        lines = ["    int x = ((((1 + 2))));\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("3", result[0])


class TestConditionFolding(unittest.TestCase):
    """Bug 2: Test operator comparison order for conditions."""

    def test_greater_than(self):
        lines = ["    if (5 > 3) {\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("true", result[0])
        self.assertEqual(steps[0]["tag"], "CF-COND")

    def test_less_than(self):
        lines = ["    if (3 < 5) {\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("true", result[0])

    def test_less_than_equal(self):
        """Bug 2: <= must not be confused with <"""
        lines = ["    if (5 <= 5) {\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("true", result[0])

    def test_greater_than_equal(self):
        """Bug 2: >= must not be confused with >"""
        lines = ["    if (5 >= 5) {\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("true", result[0])

    def test_equality(self):
        lines = ["    if (5 == 5) {\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("true", result[0])

    def test_inequality(self):
        lines = ["    if (5 != 3) {\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("true", result[0])

    def test_false_condition(self):
        lines = ["    if (0 > 1) {\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("false", result[0])

    def test_while_condition(self):
        lines = ["    while (3 < 0) {\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("false", result[0])


class TestArrayFolding(unittest.TestCase):
    """Test array initializer folding."""

    def test_all_constant_array(self):
        lines = ["    int arr[] = {1+1, 2+2, 3+3};\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("2, 4, 6", result[0])
        self.assertEqual(steps[0]["tag"], "CF-MULTI")

    def test_partial_constant_array(self):
        """Array with mix of constants and variables."""
        lines = ["    int arr[] = {1+1, x, 3+3};\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("2, x, 6", result[0])

    def test_single_literal_array_no_fold(self):
        """Array with already-computed values should not fold."""
        lines = ["    int arr[] = {1, 2, 3};\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 0)


class TestAssignmentFolding(unittest.TestCase):
    """Test folding in assignments."""

    def test_simple_assignment(self):
        lines = ["    x = 3 + 5;\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 1)
        self.assertIn("8", result[0])

    def test_no_variable_in_rhs(self):
        """Should not fold if variable is in RHS."""
        lines = ["    x = y + 5;\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 0)


class TestEdgeCases(unittest.TestCase):
    """General edge cases."""

    def test_empty_line(self):
        lines = ["\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 0)

    def test_comment_line(self):
        lines = ["    // this is a comment\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 0)

    def test_preprocessor_directive(self):
        lines = ["#include <stdio.h>\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 0)

    def test_function_call_no_fold(self):
        lines = ["    int x = func(3, 5);\n"]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 0)

    def test_multiple_lines(self):
        lines = [
            "    int a = 3 + 5;\n",
            "    int b = 10 - 2;\n",
            "    int c = x + 1;\n",
        ]
        result, steps = constant_folding(lines)
        self.assertEqual(len(steps), 2)  # a and b folded, c not


if __name__ == '__main__':
    unittest.main(verbosity=2)
