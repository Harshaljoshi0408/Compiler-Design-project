"""
test_constant_propagation.py — Tests for Constant Propagation
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from optimizer.constant_folding import constant_folding

def to_lines(code: str):
    return [line + '\n' for line in code.split('\n')]

class TestConstantPropagation(unittest.TestCase):
    def test_simple_propagation(self):
        code = """void test() {
    int x = 5;
    int y = x + 3;
}"""
        lines = to_lines(code)
        result, steps = constant_folding(lines)
        
        tags = [s['tag'] for s in steps]
        self.assertIn('CP', tags, "Should perform Constant Propagation")
        self.assertIn('CF-SIMPLE', tags, "Should perform Constant Folding after propagation")
        
        # Check result
        y_line = [l for l in result if 'int y =' in l][0]
        self.assertIn('8', y_line)

    def test_reassignment_clears_constant(self):
        code = """void test() {
    int x = 5;
    x = x + 1;
    int y = x + 3;
}"""
        lines = to_lines(code)
        result, steps = constant_folding(lines)
        # x becomes 5.
        # x = x + 1 -> CP makes it x = 5 + 1 -> CF makes it x = 6.
        # Then x is a constant 6!
        # So y = x + 3 -> CP makes it y = 6 + 3 -> CF makes it y = 9.
        
        y_line = [l for l in result if 'int y =' in l][0]
        self.assertIn('9', y_line, "x should be propagated as its new constant value 6")

    def test_propagate_into_condition(self):
        code = """void test() {
    int MAX = 10;
    if (MAX > 5) {
        return 1;
    }
}"""
        lines = to_lines(code)
        result, steps = constant_folding(lines)
        tags = [s['tag'] for s in steps]
        self.assertIn('CP', tags)
        self.assertIn('CF-COND', tags)
        
        if_line = [l for l in result if 'if' in l][0]
        self.assertIn('true', if_line)

    def test_propagate_into_return(self):
        code = """int test() {
    int code = 404;
    return code;
}"""
        lines = to_lines(code)
        result, steps = constant_folding(lines)
        tags = [s['tag'] for s in steps]
        self.assertIn('CP', tags)
        
        ret_line = [l for l in result if 'return' in l][0]
        self.assertIn('404', ret_line)

if __name__ == '__main__':
    unittest.main(verbosity=2)
