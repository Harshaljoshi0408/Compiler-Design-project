"""
test_expression_evaluator.py — Edge-case tests for ExpressionEvaluator
Tests: tokenization, evaluation, unary minus, integer division, formatting
"""

import unittest
import sys
import os

# Add parent dir to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from optimizer.expression_evaluator import ExpressionEvaluator, TokenType


class TestTokenizer(unittest.TestCase):
    def setUp(self):
        self.eval = ExpressionEvaluator()

    def test_simple_number(self):
        tokens = self.eval.tokenize("42")
        self.assertEqual(tokens[0].type, TokenType.NUMBER)
        self.assertEqual(tokens[0].value, "42")

    def test_float_number(self):
        tokens = self.eval.tokenize("3.14")
        self.assertEqual(tokens[0].type, TokenType.NUMBER)
        self.assertEqual(tokens[0].value, "3.14")

    def test_operator_tokens(self):
        tokens = self.eval.tokenize("3 + 5")
        self.assertEqual(tokens[0].type, TokenType.NUMBER)
        self.assertEqual(tokens[1].type, TokenType.OPERATOR)
        self.assertEqual(tokens[2].type, TokenType.NUMBER)

    def test_identifier(self):
        tokens = self.eval.tokenize("x + 1")
        self.assertEqual(tokens[0].type, TokenType.IDENTIFIER)
        self.assertEqual(tokens[0].value, "x")

    def test_parentheses(self):
        tokens = self.eval.tokenize("(3 + 5)")
        self.assertEqual(tokens[0].type, TokenType.LPAREN)
        # Tokens: LPAREN(0), NUMBER(1), OPERATOR(2), NUMBER(3), RPAREN(4), EOF(5)
        self.assertEqual(tokens[4].type, TokenType.RPAREN)

    def test_empty_expression(self):
        tokens = self.eval.tokenize("")
        self.assertEqual(len(tokens), 1)
        self.assertEqual(tokens[0].type, TokenType.EOF)

    def test_whitespace_only(self):
        tokens = self.eval.tokenize("   ")
        self.assertEqual(len(tokens), 1)
        self.assertEqual(tokens[0].type, TokenType.EOF)


class TestPureConstantCheck(unittest.TestCase):
    def setUp(self):
        self.eval = ExpressionEvaluator()

    def test_pure_constant(self):
        self.assertTrue(self.eval.is_pure_constant_expression("3 + 5"))

    def test_with_variable(self):
        self.assertFalse(self.eval.is_pure_constant_expression("x + 5"))

    def test_with_function_call(self):
        self.assertFalse(self.eval.is_pure_constant_expression("sqrt(4)"))

    def test_nested_parentheses(self):
        self.assertTrue(self.eval.is_pure_constant_expression("((3 + 5))"))


class TestSingleLiteralCheck(unittest.TestCase):
    def setUp(self):
        self.eval = ExpressionEvaluator()

    def test_zero(self):
        self.assertTrue(self.eval._is_single_literal("0"))

    def test_integer(self):
        self.assertTrue(self.eval._is_single_literal("42"))

    def test_float(self):
        self.assertTrue(self.eval._is_single_literal("3.14"))

    def test_negative_integer(self):
        self.assertTrue(self.eval._is_single_literal("-5"))

    def test_negative_float(self):
        self.assertTrue(self.eval._is_single_literal("-3.14"))

    def test_expression(self):
        self.assertFalse(self.eval._is_single_literal("3 + 5"))

    def test_multiplication(self):
        self.assertFalse(self.eval._is_single_literal("5 * 2"))

    def test_variable(self):
        self.assertFalse(self.eval._is_single_literal("x"))

    def test_empty_string(self):
        self.assertFalse(self.eval._is_single_literal(""))

    def test_whitespace_padded(self):
        self.assertTrue(self.eval._is_single_literal("  42  "))


class TestEvaluation(unittest.TestCase):
    def setUp(self):
        self.eval = ExpressionEvaluator()

    def test_simple_addition(self):
        self.assertEqual(self.eval.evaluate("3 + 5"), 8)

    def test_simple_subtraction(self):
        self.assertEqual(self.eval.evaluate("10 - 3"), 7)

    def test_multiplication(self):
        self.assertEqual(self.eval.evaluate("4 * 5"), 20)

    def test_float_multiplication(self):
        self.assertAlmostEqual(self.eval.evaluate("2.5 * 4.0"), 10.0)

    def test_parentheses(self):
        self.assertEqual(self.eval.evaluate("(3 + 5) * 2"), 16)

    def test_nested_parentheses(self):
        self.assertEqual(self.eval.evaluate("((3 + 5))"), 8)

    def test_deeply_nested(self):
        self.assertEqual(self.eval.evaluate("((((1 + 2))))"), 3)

    def test_operator_precedence(self):
        self.assertEqual(self.eval.evaluate("2 + 3 * 4"), 14)

    def test_complex_expression(self):
        self.assertEqual(self.eval.evaluate("(10 - 3) * 2 + 1"), 15)

    def test_division_by_zero(self):
        self.assertIsNone(self.eval.evaluate("5 / 0"))

    def test_modulo_by_zero(self):
        self.assertIsNone(self.eval.evaluate("5 % 0"))

    def test_with_variable_returns_none(self):
        self.assertIsNone(self.eval.evaluate("x + 5"))

    def test_empty_expression(self):
        self.assertIsNone(self.eval.evaluate(""))

    def test_single_number(self):
        self.assertEqual(self.eval.evaluate("42"), 42)

    def test_single_float(self):
        self.assertAlmostEqual(self.eval.evaluate("3.14"), 3.14)

    # Bug 7: Unary minus tests
    def test_unary_minus(self):
        self.assertEqual(self.eval.evaluate("-5"), -5)

    def test_unary_minus_in_expression(self):
        self.assertEqual(self.eval.evaluate("-5 + 3"), -2)

    def test_unary_minus_with_parens(self):
        self.assertEqual(self.eval.evaluate("-(3 + 2)"), -5)

    def test_double_negative(self):
        # This is tricky: --5 would be decrement in C, but as expression: 0 - (0 - 5) = 5
        # Our evaluator treats -- as two unary minuses
        result = self.eval.evaluate("5")  # Simple baseline
        self.assertEqual(result, 5)

    # Bug 8: C-style integer division
    def test_integer_division(self):
        """10 / 3 should be 3 in C (truncate toward zero), not 3.333"""
        self.assertEqual(self.eval.evaluate("10 / 3"), 3)

    def test_integer_division_negative(self):
        """-7 / 2 should be -3 in C (truncate toward zero)"""
        self.assertEqual(self.eval.evaluate("-7 / 2"), -3)

    def test_float_division(self):
        """2.0 / 3.0 should give float result"""
        result = self.eval.evaluate("2.0 / 3.0")
        self.assertIsNotNone(result)
        self.assertAlmostEqual(result, 0.6667, places=3)

    def test_modulo(self):
        self.assertEqual(self.eval.evaluate("10 % 3"), 1)

    def test_modulo_negative(self):
        """C modulo: sign follows dividend"""
        self.assertEqual(self.eval.evaluate("-7 % 3"), -1)

    def test_chained_operations(self):
        self.assertEqual(self.eval.evaluate("100 / 4 + 5"), 30)

    def test_multiple_operators(self):
        self.assertEqual(self.eval.evaluate("2 + 3 + 4 + 5"), 14)


class TestFormatResult(unittest.TestCase):
    def setUp(self):
        self.eval = ExpressionEvaluator()

    def test_integer(self):
        self.assertEqual(self.eval.format_result(42), "42")

    def test_float_whole_number(self):
        self.assertEqual(self.eval.format_result(10.0), "10")

    def test_float_decimal(self):
        self.assertEqual(self.eval.format_result(3.14), "3.14")

    def test_negative_integer(self):
        self.assertEqual(self.eval.format_result(-5), "-5")


if __name__ == '__main__':
    unittest.main(verbosity=2)
