"""
test_integration.py — Full Pipeline Integration Tests
Tests the complete optimizer with all techniques working together.
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from optimizer import run_optimizer


class TestEmptyInput(unittest.TestCase):
    """Test edge cases with empty/null input."""

    def test_empty_string(self):
        result = run_optimizer("")
        self.assertEqual(result["summary"]["total"], 0)
        self.assertEqual(result["optimized_code"], "")

    def test_whitespace_only(self):
        result = run_optimizer("   \n  \n  ")
        self.assertEqual(result["summary"]["total"], 0)

    def test_none_input(self):
        result = run_optimizer(None)
        self.assertEqual(result["summary"]["total"], 0)

    def test_only_comments(self):
        code = """// This is a comment
// Another comment
/* Block comment */"""
        result = run_optimizer(code)
        self.assertEqual(result["summary"]["total"], 0)

    def test_only_preprocessor(self):
        code = """#include <stdio.h>
#include <stdlib.h>
#define MAX 100"""
        result = run_optimizer(code)
        self.assertEqual(result["summary"]["total"], 0)


class TestFullPipeline(unittest.TestCase):
    """Test all optimizations working together."""

    def test_cf_then_dce(self):
        """Constant folding creates conditions that DCE can eliminate."""
        code = """int test() {
    if (5 > 10) {
        printf("dead");
    }
    return 0;
}"""
        result = run_optimizer(code)
        # CF should fold 5 > 10 to false, then DCE should remove the block
        self.assertTrue(result["summary"]["total"] > 0)

    def test_all_three_techniques(self):
        code = """int compute() {
    int base = 10 * 5 + 2;
    
    for (int i = 0; i < 10; i++) {
        int step = 6 * 7;
        int result = base + step;
    }
    
    return 0;
    printf("dead");
}"""
        result = run_optimizer(code)
        s = result["summary"]
        self.assertTrue(s["constant_folding"] > 0, "Should have CF")
        self.assertTrue(s["dead_code_elimination"] > 0, "Should have DCE")

    def test_real_world_program(self):
        code = """#include <stdio.h>

int main() {
    int a = 3 + 5;
    int b = (10 - 3) * 2;
    int unused = 42;
    
    if (5 > 3) {
        printf("%d %d\\n", a, b);
    }
    
    for (int i = 0; i < 10; i++) {
        int step = 6 * 7;
        printf("%d\\n", step);
    }
    
    return 0;
}"""
        result = run_optimizer(code)
        self.assertTrue(result["summary"]["total"] > 0)
        self.assertIn("optimized_code", result)
        self.assertIn("steps", result)

    def test_return_zero_no_false_positive(self):
        """Bug 1 fix: return 0 should not be counted as optimization."""
        code = """int main() {
    return 0;
}"""
        result = run_optimizer(code)
        cf_steps = [s for s in result["steps"] if s["tag"].startswith("CF")]
        self.assertEqual(len(cf_steps), 0)

    def test_summary_counts_correct(self):
        code = """int test() {
    int a = 3 + 5;
    int b = 10 - 2;
    return a + b;
}"""
        result = run_optimizer(code)
        s = result["summary"]
        self.assertEqual(s["total"], s["constant_folding"] + s["dead_code_elimination"] + s["loop_optimization"])

    def test_backward_compat_import(self):
        """Ensure old import path still works."""
        from optimizer_engine import run_optimizer as old_run
        result = old_run("int x = 3 + 5;")
        self.assertTrue(result["summary"]["total"] >= 0)


class TestOptimizationStatistics(unittest.TestCase):
    """Test new optimization statistics."""

    def test_lines_before_after(self):
        code = """int test() {
    int a = 3 + 5;
    return a;
}"""
        result = run_optimizer(code)
        self.assertIn("lines_before", result["summary"])
        self.assertIn("lines_after", result["summary"])
        self.assertTrue(result["summary"]["lines_before"] > 0)

    def test_reduction_percentage(self):
        code = """int test() {
    int a = 3 + 5;
    int unused = 42;
    return a;
}"""
        result = run_optimizer(code)
        self.assertIn("reduction_pct", result["summary"])


class TestComplexPrograms(unittest.TestCase):
    """Test with more complex C programs."""

    def test_nested_ifs(self):
        code = """int test() {
    int x = 5;
    if (x > 0) {
        if (x > 3) {
            return 1;
        }
    }
    return 0;
}"""
        result = run_optimizer(code)
        # Should not crash
        self.assertIsNotNone(result["optimized_code"])

    def test_multiple_functions(self):
        code = """int add(int a, int b) {
    return a + b;
}

int main() {
    int x = 3 + 5;
    int result = add(x, 10);
    return 0;
}"""
        result = run_optimizer(code)
        self.assertIsNotNone(result["optimized_code"])

    def test_switch_case(self):
        code = """int test(int x) {
    switch (x) {
        case 1:
            return 10;
            break;
        case 2:
            return 20;
        default:
            return 0;
    }
}"""
        result = run_optimizer(code)
        self.assertIsNotNone(result["optimized_code"])

    def test_complex_loop(self):
        code = """void test() {
    int sum = 0;
    for (int i = 0; i < 100; i++) {
        for (int j = 0; j < 100; j++) {
            sum += i * j;
        }
    }
    printf("%d", sum);
}"""
        result = run_optimizer(code)
        self.assertIsNotNone(result["optimized_code"])

    def test_string_operations(self):
        """Code with strings should not crash the optimizer."""
        code = """void test() {
    char* msg = "hello world";
    printf("%s\\n", msg);
}"""
        result = run_optimizer(code)
        self.assertIsNotNone(result["optimized_code"])


if __name__ == '__main__':
    unittest.main(verbosity=2)
