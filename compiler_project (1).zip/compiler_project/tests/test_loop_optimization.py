"""
test_loop_optimization.py — Edge-case tests for Loop Optimization
Tests: LICM, strength reduction, loop unrolling
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from optimizer.loop_optimization import (
    LoopAnalyzer,
    loop_optimization,
    find_strength_reduction,
    find_loop_unrolling,
)


def to_lines(code: str):
    """Convert code string to list of lines with newlines."""
    lines = code.split('\n')
    return [line + '\n' for line in lines]


class TestLoopAnalyzer(unittest.TestCase):
    """Test LoopAnalyzer detection."""

    def test_detect_for_loop(self):
        code = """void test() {
    for (int i = 0; i < 10; i++) {
        x++;
    }
}"""
        analyzer = LoopAnalyzer(to_lines(code))
        loops = analyzer.find_loops()
        self.assertEqual(len(loops), 1)
        self.assertEqual(loops[0][1], 'for')

    def test_detect_while_loop(self):
        code = """void test() {
    while (x < 10) {
        x++;
    }
}"""
        analyzer = LoopAnalyzer(to_lines(code))
        loops = analyzer.find_loops()
        self.assertEqual(len(loops), 1)
        self.assertEqual(loops[0][1], 'while')

    def test_detect_do_while(self):
        code = """void test() {
    do {
        x++;
    } while (x < 10);
}"""
        analyzer = LoopAnalyzer(to_lines(code))
        loops = analyzer.find_loops()
        # Known: do-while also matches the trailing while, so 2 loops detected
        # At least one should be do-while
        loop_types = [lt for _, lt, _ in loops]
        self.assertIn('do-while', loop_types)

    def test_no_loops(self):
        code = """int test() {
    int x = 5;
    return x;
}"""
        analyzer = LoopAnalyzer(to_lines(code))
        loops = analyzer.find_loops()
        self.assertEqual(len(loops), 0)

    def test_nested_loops(self):
        code = """void test() {
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            x++;
        }
    }
}"""
        analyzer = LoopAnalyzer(to_lines(code))
        loops = analyzer.find_loops()
        self.assertEqual(len(loops), 2)


class TestLICM(unittest.TestCase):
    """Test Loop Invariant Code Motion."""

    def test_constant_expression_hoisted(self):
        code = """void test() {
    for (int i = 0; i < 10; i++) {
        int x = 5 * 2;
        sum += x;
    }
}"""
        lines = to_lines(code)
        result, steps = loop_optimization(lines)
        licm_steps = [s for s in steps if s['tag'] == 'LICM']
        self.assertTrue(len(licm_steps) >= 1, "Should hoist constant expression")

    def test_loop_variable_not_hoisted(self):
        code = """void test() {
    for (int i = 0; i < 10; i++) {
        int x = i * 2;
    }
}"""
        lines = to_lines(code)
        result, steps = loop_optimization(lines)
        licm_steps = [s for s in steps if s['tag'] == 'LICM']
        self.assertEqual(len(licm_steps), 0, "Expression using loop var should not be hoisted")

    def test_modified_var_not_hoisted(self):
        """If a variable is modified inside the loop, expressions using it aren't invariant."""
        code = """void test() {
    int a = 5;
    for (int i = 0; i < 10; i++) {
        int x = a + 1;
        a++;
    }
}"""
        lines = to_lines(code)
        result, steps = loop_optimization(lines)
        licm_steps = [s for s in steps if s['tag'] == 'LICM']
        self.assertEqual(len(licm_steps), 0, "Expression using modified var should not be hoisted")

    def test_no_invariant_code(self):
        code = """void test() {
    for (int i = 0; i < 10; i++) {
        sum += i;
    }
}"""
        lines = to_lines(code)
        result, steps = loop_optimization(lines)
        licm_steps = [s for s in steps if s['tag'] == 'LICM']
        self.assertEqual(len(licm_steps), 0)

    def test_empty_loop_body(self):
        code = """void test() {
    for (int i = 0; i < 10; i++) {
    }
}"""
        lines = to_lines(code)
        result, steps = loop_optimization(lines)
        licm_steps = [s for s in steps if s['tag'] == 'LICM']
        self.assertEqual(len(licm_steps), 0)


class TestStrengthReduction(unittest.TestCase):
    """Test strength reduction in loops."""

    def test_multiply_by_power_of_2(self):
        code = """void test() {
    for (int i = 0; i < 10; i++) {
        x = i * 8;
    }
}"""
        lines = to_lines(code)
        result, steps = find_strength_reduction(lines)
        sr_steps = [s for s in steps if s['tag'] == 'LOOP-SR']
        self.assertEqual(len(sr_steps), 1)
        self.assertIn("<<", sr_steps[0]["after"])

    def test_divide_by_power_of_2(self):
        code = """void test() {
    for (int i = 0; i < 10; i++) {
        x = i / 4;
    }
}"""
        lines = to_lines(code)
        result, steps = find_strength_reduction(lines)
        sr_steps = [s for s in steps if s['tag'] == 'LOOP-SR']
        self.assertEqual(len(sr_steps), 1)
        self.assertIn(">>", sr_steps[0]["after"])

    def test_modulo_by_power_of_2(self):
        code = """void test() {
    for (int i = 0; i < 10; i++) {
        x = i % 16;
    }
}"""
        lines = to_lines(code)
        result, steps = find_strength_reduction(lines)
        sr_steps = [s for s in steps if s['tag'] == 'LOOP-SR']
        self.assertEqual(len(sr_steps), 1)
        self.assertIn("&", sr_steps[0]["after"])

    def test_no_power_of_2(self):
        """Multiply by non-power-of-2 should not be reduced."""
        code = """void test() {
    for (int i = 0; i < 10; i++) {
        x = i * 7;
    }
}"""
        lines = to_lines(code)
        result, steps = find_strength_reduction(lines)
        sr_steps = [s for s in steps if s['tag'] == 'LOOP-SR']
        self.assertEqual(len(sr_steps), 0)

    def test_not_in_loop(self):
        """Strength reduction should only apply inside loops."""
        code = """void test() {
    x = i * 8;
}"""
        lines = to_lines(code)
        result, steps = find_strength_reduction(lines)
        self.assertEqual(len(steps), 0)

    def test_multiply_by_1(self):
        """x * 1 is power of 2 (2^0) but shift by 0 — handled correctly."""
        code = """void test() {
    for (int i = 0; i < 10; i++) {
        x = i * 1;
    }
}"""
        lines = to_lines(code)
        result, steps = find_strength_reduction(lines)
        sr_steps = [s for s in steps if s['tag'] == 'LOOP-SR']
        self.assertEqual(len(sr_steps), 1)
        self.assertIn("<< 0", sr_steps[0]["after"])

    def test_multiply_by_2(self):
        code = """void test() {
    for (int i = 0; i < 10; i++) {
        x = i * 2;
    }
}"""
        lines = to_lines(code)
        result, steps = find_strength_reduction(lines)
        sr_steps = [s for s in steps if s['tag'] == 'LOOP-SR']
        self.assertEqual(len(sr_steps), 1)
        self.assertIn("<< 1", sr_steps[0]["after"])


class TestLoopUnrolling(unittest.TestCase):
    """Test loop unrolling suggestions."""

    def test_small_for_loop(self):
        code = """void test() {
    for (int i = 0; i < 3; i++) {
        printf("x");
    }
}"""
        lines = to_lines(code)
        result, steps = find_loop_unrolling(lines)
        self.assertEqual(len(steps), 1)
        self.assertEqual(steps[0]["tag"], "LOOP-UNROLL")

    def test_large_for_loop_not_unrolled(self):
        """Loops with > 4 iterations should not be suggested for unrolling."""
        code = """void test() {
    for (int i = 0; i < 100; i++) {
        printf("x");
    }
}"""
        lines = to_lines(code)
        result, steps = find_loop_unrolling(lines)
        self.assertEqual(len(steps), 0)

    def test_for_loop_2_iterations(self):
        code = """void test() {
    for (int i = 0; i < 2; i++) {
        printf("x");
    }
}"""
        lines = to_lines(code)
        result, steps = find_loop_unrolling(lines)
        self.assertEqual(len(steps), 1)

    def test_for_loop_4_iterations(self):
        code = """void test() {
    for (int i = 0; i < 4; i++) {
        printf("x");
    }
}"""
        lines = to_lines(code)
        result, steps = find_loop_unrolling(lines)
        self.assertEqual(len(steps), 1)

    def test_for_loop_5_iterations_not_unrolled(self):
        code = """void test() {
    for (int i = 0; i < 5; i++) {
        printf("x");
    }
}"""
        lines = to_lines(code)
        result, steps = find_loop_unrolling(lines)
        self.assertEqual(len(steps), 0)

    def test_while_small_bound(self):
        code = """void test() {
    while (x < 3) {
        printf("x");
    }
}"""
        lines = to_lines(code)
        result, steps = find_loop_unrolling(lines)
        self.assertEqual(len(steps), 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
