"""
test_cse.py — Tests for Common Subexpression Elimination
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from optimizer.common_subexpr_elimination import common_subexpression_elimination

def to_lines(code: str):
    return [line + '\n' for line in code.split('\n')]

class TestCSE(unittest.TestCase):
    def test_simple_cse(self):
        code = """void test() {
    int x = a + b;
    int y = a + b;
}"""
        lines = to_lines(code)
        result, steps = common_subexpression_elimination(lines)
        
        tags = [s['tag'] for s in steps]
        self.assertIn('CSE', tags, "Should perform CSE")
        
        y_line = [l for l in result if 'int y =' in l][0]
        self.assertIn('int y = x;', y_line)

    def test_reassignment_invalidates(self):
        code = """void test() {
    int x = a + b;
    a = a + 1;
    int y = a + b;
}"""
        lines = to_lines(code)
        result, steps = common_subexpression_elimination(lines)
        
        y_line = [l for l in result if 'int y =' in l][0]
        self.assertIn('a + b', y_line, "Should not perform CSE after 'a' is modified")

    def test_compound_assignment_invalidates(self):
        code = """void test() {
    int x = a + b;
    a += 1;
    int y = a + b;
}"""
        lines = to_lines(code)
        result, steps = common_subexpression_elimination(lines)
        
        y_line = [l for l in result if 'int y =' in l][0]
        self.assertIn('a + b', y_line, "Should not perform CSE after 'a' is modified")

    def test_no_cse_on_constants(self):
        code = """void test() {
    int x = 5;
    int y = 5;
}"""
        lines = to_lines(code)
        result, steps = common_subexpression_elimination(lines)
        
        tags = [s['tag'] for s in steps]
        self.assertNotIn('CSE', tags, "Should not perform CSE on single literals")

if __name__ == '__main__':
    unittest.main(verbosity=2)
