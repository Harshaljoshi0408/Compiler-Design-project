// ══════════════════════════════════════════════════════
//  main.js  —  C Code Optimizer Frontend Logic
// ══════════════════════════════════════════════════════

// ── State ──────────────────────────────────────────────
let allSteps = [];
let inputEditor = null;
let diffEditor = null;
let originalCodeLines = [];
let currentAnimationStep = -1;
let animationOriginalModel = null;
let animationModifiedModel = null;

// Monaco setup
require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.41.0/min/vs' }});
require(['vs/editor/editor.main'], function() {
    inputEditor = monaco.editor.create(document.getElementById('input-editor'), {
        value: "",
        language: 'c',
        theme: 'vs-dark',
        minimap: { enabled: false },
        automaticLayout: true,
        scrollBeyondLastLine: false,
        fontSize: 13,
        padding: { top: 10 }
    });

    inputEditor.onDidChangeModelContent(() => {
        const lines = inputEditor.getValue().split('\n').length;
        document.getElementById('char-count').textContent = lines + ' lines';
    });

    diffEditor = monaco.editor.createDiffEditor(document.getElementById('diff-editor-container'), {
        theme: 'vs-dark',
        readOnly: true,
        renderSideBySide: false, // inline diff
        minimap: { enabled: false },
        automaticLayout: true,
        scrollBeyondLastLine: false,
        fontSize: 13,
        padding: { top: 10 }
    });
});

const SAMPLE = `#include <stdio.h>

int main() {
    // Constant Folding - Simple Expression
    int a = 3 + 5;
    float b = 2.0 * 4.0;
    
    // Constant Folding - Mixed Expression
    int c = (10 - 3) * 2;
    int d = 100 / 4 + 5;
    
    // Constant Folding - In Condition
    if (5 > 3) {
        a = 10;
    }

    // Unreachable Code (after return)
    if (a > 5) {
        return 1;
        printf("This line is dead!\\n");
        c = 999;
    }

    // Unused Variables
    int unused1 = 42;
    float unused2 = 3.14;

    // Overwritten Values
    int temp = 5;
    temp = 10;

    // Always False Condition
    if (0 > 1) {
        printf("Never prints\\n");
    }

    // Loop Optimization - Invariant Code Motion
    for (int i = 0; i < 10; i++) {
        int step = 6 * 7;
        int result = a + i;
        printf("%d %d\\n", step, result);
    }

    // Loop Optimization - Strength Reduction (multiplication by power of 2)
    int result = 0;
    for (int j = 0; j < 5; j++) {
        result = j * 8;  // Will be optimized to j << 3
        printf("%d\\n", result);
    }
    
    // Loop Optimization - Loop Unrolling candidate
    for (int k = 0; k < 3; k++) {
        printf("Unroll me\\n");
    }

    while (c > 0) {
        int base = 8 + 12;
        c--;
    }

    return 0;
}`;

// ── Line counter ────────────────────────────────────────
// Line counter logic is handled in Monaco setup

function loadSample() {
  if (inputEditor) {
    inputEditor.setValue(SAMPLE);
    document.getElementById('char-count').textContent = SAMPLE.split('\n').length + ' lines';
    showToast('Sample code loaded ✓');
  }
}

function clearAll() {
  if (inputEditor) inputEditor.setValue('');
  document.getElementById('output-placeholder').style.display = 'block';
  document.getElementById('diff-editor-container').style.display = 'none';
  document.getElementById('steps-wrapper').innerHTML =
    '<div class="empty"><div class="icon">🔍</div><div>Optimization steps will appear here</div><div style="font-size:11px;">Click any step for explanation</div></div>';
  document.getElementById('filter-bar').style.display = 'none';
  document.getElementById('summary-bar').style.display = 'none';
  document.getElementById('output-status').textContent = 'Not optimized yet';
  document.getElementById('char-count').textContent = '0 lines';
  document.getElementById('btn-step').style.display = 'none';
  allSteps = [];
  currentAnimationStep = -1;
}

// ── Main optimizer call ─────────────────────────────────
async function runOptimizer() {
  if (!inputEditor) return;
  const code = inputEditor.getValue();
  if (!code.trim()) { showToast('Please write some code or load the sample!'); return; }
  
  // Reset animation state
  currentAnimationStep = -1;
  document.getElementById('btn-step').textContent = '⏭ Step Through';
  document.getElementById('btn-step').style.display = 'none';

  const btn = document.getElementById('btn-optimize');
  btn.textContent = '⏳ Optimizing...';
  btn.disabled = true;

  try {
    const res  = await fetch('/optimize', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ code })
    });
    
    if (!res.ok) {
      throw new Error('Server returned ' + res.status + ' ' + res.statusText);
    }
    
    const data = await res.json();

    if (data.error) {
      showToast('Error: ' + data.error);
      return;
    }

    // Output code (Monaco Diff Viewer)
    document.getElementById('output-placeholder').style.display = 'none';
    document.getElementById('diff-editor-container').style.display = 'block';
    
    // Store original code lines for animation
    originalCodeLines = code.split('\n');
    
    // Display diff
    const originalModel = monaco.editor.createModel(code, 'c');
    const modifiedModel = monaco.editor.createModel(data.optimized_code, 'c');
    diffEditor.setModel({
      original: originalModel,
      modified: modifiedModel
    });

    // Status
    const total = data.summary.total;
    document.getElementById('output-status').textContent =
      total > 0 ? `✅ ${total} optimizations applied` : '✓ Already optimized';
    document.getElementById('output-status').style.color =
      total > 0 ? 'var(--green)' : 'var(--muted)';

    // Summary counts
    document.getElementById('sum-cf').textContent   = data.summary.constant_folding;
    document.getElementById('sum-dce').textContent  = data.summary.dead_code_elimination;
    document.getElementById('sum-licm').textContent = data.summary.loop_optimization;
    
    document.getElementById('summary-bar').style.display = total > 0 ? 'grid' : 'none';

    // Steps
    allSteps = data.steps;
    renderSteps(allSteps);

    if (total > 0) {
      document.getElementById('filter-bar').style.display = 'flex';
      document.getElementById('btn-step').style.display = 'inline-block';
      showToast(`🎉 ${total} optimization${total > 1 ? 's' : ''} found!`);
    } else {
      document.getElementById('filter-bar').style.display = 'none';
      showToast('Code is already clean!');
    }

  } catch (e) {
    console.error('Optimization error:', e);
    showToast('Error: ' + (e.message || 'Cannot connect to server. Is Flask running?'));
  } finally {
    btn.textContent = '▶ Optimize Code';
    btn.disabled = false;
  }
}

// ── Render step cards ────────────────────────────────────
function renderSteps(steps) {
  const wrapper = document.getElementById('steps-wrapper');

  if (steps.length === 0) {
    wrapper.innerHTML =
      '<div class="empty"><div class="icon">✅</div><div>No steps in this filter</div></div>';
    return;
  }

  const tagMap = { 
    CF: 'cf', DCE: 'dce', LICM: 'licm',
    // CF sub-techniques - all map to cf color
    'CF-SIMPLE': 'cf', 'CF-MIXED': 'cf', 'CF-MULTI': 'cf', 'CF-COND': 'cf',
    // DCE sub-techniques - all map to dce color
    'DCE-UCE': 'dce', 'DCE-UVE': 'dce', 'DCE-OVE': 'dce', 'DCE-AFC': 'dce',
    // Loop sub-techniques - all map to licm color
    'LOOP-SR': 'licm', 'LOOP-UNROLL': 'licm'
  };
  const accentMap = {
    cf: 'var(--purple)',
    dce: 'var(--red)',
    licm: 'var(--green)'
  };

  wrapper.innerHTML = steps.map((s, i) => {
    const cls    = tagMap[s.tag] || 'cf';
    const accent = accentMap[cls];
    return `
    <div class="step-card" id="card-${i}"
         style="--accent-color:${accent};"
         onclick="toggleCard(${i})">
      <div class="step-head">
        <span class="tag ${cls}">${s.tag}</span>
        <span style="font-size:11px;font-weight:600;color:var(--text);">${s.technique}</span>
        <span class="step-line-no">Line ${s.line_no}</span>
      </div>
      <div class="code-row">
        <div class="code-before">${escHtml(s.before)}</div>
        <div class="code-after">${escHtml(s.after)}</div>
      </div>
      <div class="explain-box" id="explain-${i}">
        <div>${s.explanation}</div>
        <div class="exam-tip">📝 ${s.tip}</div>
      </div>
    </div>`;
  }).join('');
}

function toggleCard(i) {
  const card    = document.getElementById('card-' + i);
  const explain = document.getElementById('explain-' + i);
  const isOpen  = explain.classList.contains('visible');

  document.querySelectorAll('.explain-box').forEach(b => b.classList.remove('visible'));
  document.querySelectorAll('.step-card').forEach(c => c.classList.remove('open'));

  if (!isOpen) {
    explain.classList.add('visible');
    card.classList.add('open');
  }
}

// ── Filter steps ─────────────────────────────────────────
// Group all sub-techniques under 3 main categories
const CATEGORY_MAP = {
  // Constant Folding sub-techniques
  'CF': 'cf', 'CF-SIMPLE': 'cf', 'CF-MIXED': 'cf', 'CF-MULTI': 'cf', 'CF-COND': 'cf', 'CP': 'cf', 'CSE': 'cf',
  // Dead Code Elimination sub-techniques  
  'DCE': 'dce', 'DCE-UCE': 'dce', 'DCE-UVE': 'dce', 'DCE-OVE': 'dce', 'DCE-AFC': 'dce',
  // Loop Optimization sub-techniques
  'LICM': 'licm', 'LOOP-SR': 'licm', 'LOOP-UNROLL': 'licm'
};

function filterSteps(filter, btn) {
  document.querySelectorAll('.filter-btn').forEach(b => {
    b.className = 'filter-btn';
  });
  btn.classList.add('active-' + filter);

  const filtered = filter === 'all'
    ? allSteps
    : allSteps.filter(s => CATEGORY_MAP[s.tag] === filter);

  renderSteps(filtered);
}

// ── Helpers ──────────────────────────────────────────────
function escHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

// ── Step-by-Step Animation ──────────────────────────────
function startStepAnimation() {
  if (allSteps.length === 0 || !diffEditor) return;
  
  const btn = document.getElementById('btn-step');
  
  // If starting fresh
  if (currentAnimationStep === -1) {
    currentAnimationStep = 0;
    btn.textContent = '⏭ Next Step';
    
    // Set both panes to original code
    const originalCode = originalCodeLines.join('\n');
    animationOriginalModel = monaco.editor.createModel(originalCode, 'c');
    animationModifiedModel = monaco.editor.createModel(originalCode, 'c');
    
    diffEditor.setModel({
      original: animationOriginalModel,
      modified: animationModifiedModel
    });
    
    showToast('Animation started. Click Next Step.');
    
    // Reset cards
    document.querySelectorAll('.step-card').forEach(c => c.classList.remove('open'));
    
    return;
  }
  
  // If we reached the end
  if (currentAnimationStep >= allSteps.length) {
    showToast('Optimization complete!');
    btn.textContent = '⏭ Step Through';
    currentAnimationStep = -1;
    return;
  }
  
  // Apply current step
  const step = allSteps[currentAnimationStep];
  
  // Highlight card
  document.querySelectorAll('.step-card').forEach(c => c.classList.remove('open'));
  const card = document.getElementById(`card-${currentAnimationStep}`);
  if (card) {
    card.classList.add('open');
    card.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  
  // Apply change to modified model
  let currentText = animationModifiedModel.getValue();
  
  // We split by newline, find the first matching 'before' line and replace it
  // For loop optimizations, 'before' might contain newlines
  if (step.before !== undefined && step.after !== undefined) {
    const beforeStr = step.before;
    const afterStr = step.after;
    currentText = currentText.replace(beforeStr, afterStr);
    animationModifiedModel.setValue(currentText);
  }
  
  currentAnimationStep++;
  
  if (currentAnimationStep >= allSteps.length) {
    btn.textContent = '🎉 Finish';
  }
}


function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2800);
}

// Load sample on page load
window.onload = loadSample;
