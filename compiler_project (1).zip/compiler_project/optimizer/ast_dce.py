"""
ast_dce.py — AST Dead Code Elimination
"""

from pycparser import c_ast, c_generator
from optimizer.ast_transformer import NodeTransformer

class DeadCodeEliminator(NodeTransformer):
    def __init__(self):
        self.steps = []
        self.generator = c_generator.CGenerator()

    def visit_Compound(self, node):
        # Visit children first to simplify nested structures
        self.generic_visit(node)
        
        if not node.block_items:
            return node
            
        new_items = []
        dead_code_found = False
        
        for item in node.block_items:
            if dead_code_found:
                # This item is unreachable
                before_code = self.generator.visit(item)
                self.steps.append({
                    "line_no": item.coord.line if item.coord else 0,
                    "technique": "AST Dead Code (Unreachable)",
                    "tag": "DCE-UCE",
                    "color": "red",
                    "before": before_code,
                    "after": "// Removed unreachable code",
                    "explanation": f"The statement `{before_code}` is unreachable because it follows a return/break/continue.",
                    "tip": "Exam tip: Control flow analysis identifies dead code."
                })
                continue
                
            new_items.append(item)
            if isinstance(item, (c_ast.Return, c_ast.Break, c_ast.Continue)):
                dead_code_found = True
                
        node.block_items = new_items
        return node
        
    def visit_If(self, node):
        self.generic_visit(node)
        
        # Check if condition is a constant
        if isinstance(node.cond, c_ast.Constant):
            val = int(node.cond.value) if 'int' in node.cond.type else float(node.cond.value)
            before_code = self.generator.visit(node)
            
            if val == 0:
                # Condition always false
                self.steps.append({
                    "line_no": node.coord.line if node.coord else 0,
                    "technique": "AST Dead Code (Always False)",
                    "tag": "DCE-AFC",
                    "color": "red",
                    "before": before_code,
                    "after": self.generator.visit(node.iffalse) if node.iffalse else "// Removed false if-branch",
                    "explanation": "The condition evaluated to 0 (false) at compile-time, so the branch was removed.",
                    "tip": "Exam tip: Constant folding often feeds into dead code elimination."
                })
                # Return the else block if it exists, otherwise empty Compound
                return node.iffalse if node.iffalse else c_ast.EmptyStatement()
            else:
                # Condition always true
                self.steps.append({
                    "line_no": node.coord.line if node.coord else 0,
                    "technique": "AST Dead Code (Always True)",
                    "tag": "DCE-AFC",
                    "color": "red",
                    "before": before_code,
                    "after": self.generator.visit(node.iftrue) if node.iftrue else "// Empty true branch",
                    "explanation": "The condition evaluated to true at compile-time, so the check was removed.",
                    "tip": "Exam tip: Always-true conditions can be bypassed."
                })
                return node.iftrue
                
        return node
