"""
cfg_builder.py — Control Flow Graph Generator
"""

from pycparser import c_ast

class BasicBlock:
    def __init__(self, id):
        self.id = id
        self.statements = []
        self.successors = []
        self.predecessors = []
        
    def add_statement(self, stmt):
        self.statements.append(stmt)
        
    def add_successor(self, block):
        if block not in self.successors:
            self.successors.append(block)
        if self not in block.predecessors:
            block.predecessors.append(self)
            
    def __repr__(self):
        return f"Block(id={self.id}, stmts={len(self.statements)}, succs={[s.id for s in self.successors]})"

class CFG:
    def __init__(self):
        self.blocks = []
        self.entry = None
        self.exit = None

class CFGBuilder(c_ast.NodeVisitor):
    def __init__(self):
        self.cfg = CFG()
        self.current_block = None
        self.block_counter = 0
        
    def new_block(self):
        b = BasicBlock(self.block_counter)
        self.block_counter += 1
        self.cfg.blocks.append(b)
        return b
        
    def build(self, ast):
        self.cfg.entry = self.new_block()
        self.current_block = self.cfg.entry
        self.visit(ast)
        self.cfg.exit = self.new_block()
        self.current_block.add_successor(self.cfg.exit)
        return self.cfg
        
    def visit_Compound(self, node):
        if node.block_items:
            for item in node.block_items:
                self.visit(item)
                
    def visit_If(self, node):
        cond_block = self.current_block
        cond_block.add_statement(node.cond)
        
        true_block = self.new_block()
        cond_block.add_successor(true_block)
        
        merge_block = self.new_block()
        
        self.current_block = true_block
        if node.iftrue:
            self.visit(node.iftrue)
        self.current_block.add_successor(merge_block)
        
        if node.iffalse:
            false_block = self.new_block()
            cond_block.add_successor(false_block)
            self.current_block = false_block
            self.visit(node.iffalse)
            self.current_block.add_successor(merge_block)
        else:
            cond_block.add_successor(merge_block)
            
        self.current_block = merge_block
        
    def visit_While(self, node):
        header_block = self.new_block()
        self.current_block.add_successor(header_block)
        
        header_block.add_statement(node.cond)
        
        body_block = self.new_block()
        header_block.add_successor(body_block)
        
        exit_block = self.new_block()
        header_block.add_successor(exit_block)
        
        self.current_block = body_block
        if node.stmt:
            self.visit(node.stmt)
        self.current_block.add_successor(header_block)
        
        self.current_block = exit_block

    def visit_For(self, node):
        if node.init:
            self.visit(node.init)
            
        header_block = self.new_block()
        self.current_block.add_successor(header_block)
        
        if node.cond:
            header_block.add_statement(node.cond)
            
        body_block = self.new_block()
        header_block.add_successor(body_block)
        
        exit_block = self.new_block()
        header_block.add_successor(exit_block)
        
        self.current_block = body_block
        if node.stmt:
            self.visit(node.stmt)
        if node.next:
            self.current_block.add_statement(node.next)
            
        self.current_block.add_successor(header_block)
        
        self.current_block = exit_block
        
    def generic_visit(self, node):
        if self.current_block and not isinstance(node, (c_ast.FuncDef, c_ast.FileAST)):
            self.current_block.add_statement(node)
        super().generic_visit(node)
