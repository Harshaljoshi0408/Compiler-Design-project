"""
optimizer — Modular C Code Optimization Package
Techniques: Constant Folding, Dead Code Elimination, Loop Optimization (LICM)

This package splits the optimizer_engine.py monolith into focused modules:
  - expression_evaluator.py : Tokenizer & expression evaluation
  - constant_folding.py     : Constant folding (simple, mixed, condition, array)
  - dead_code_elimination.py: DCE (unreachable, unused vars, overwrites, false conds)
  - loop_optimization.py    : LICM, strength reduction, loop unrolling
  - utils.py                : Shared helpers (block finding, variable read checks)
"""

from optimizer.expression_evaluator import TokenType, Token, ExpressionEvaluator
from optimizer.constant_folding import constant_folding
from optimizer.common_subexpr_elimination import common_subexpression_elimination
from optimizer.dead_code_elimination import (
    Block, ScopeAnalyzer,
    find_unreachable_code,
    find_unused_variables,
    find_overwritten_values,
    find_always_false_conditions,
    dead_code_elimination,
)
from optimizer.loop_optimization import (
    LoopAnalyzer,
    loop_optimization,
    find_strength_reduction,
    find_loop_unrolling,
)
from optimizer.utils import find_block_end, is_variable_read, evaluate_condition

from typing import Dict, List


def run_optimizer(c_code: str) -> Dict:
    """
    Run all three optimization passes and return full report.
    Pass order: CF → DCE → Loop Opt
    """
    if not c_code or not c_code.strip():
        return {
            "original_code": c_code or "",
            "optimized_code": c_code or "",
            "steps": [],
            "summary": {
                "constant_folding": 0,
                "cf_simple": 0, "cf_mixed": 0, "cf_multi": 0, "cf_cond": 0,
                "dead_code_elimination": 0,
                "dead_code_unreachable": 0, "dead_code_unused_var": 0,
                "dead_code_overwritten": 0, "dead_code_false_cond": 0,
                "loop_optimization": 0,
                "loop_licm": 0, "loop_strength_reduction": 0, "loop_unrolling": 0,
                "total": 0,
                "lines_before": 0, "lines_after": 0, "reduction_pct": 0.0,
            }
        }

    lines = c_code.split('\n')
    # Ensure all lines end with newline for consistent processing
    lines = [line if line.endswith('\n') else line + '\n' for line in lines]
    if lines and lines[-1].strip() == '':
        lines = lines[:-1]

    original_line_count = len(lines)
    all_steps: List[Dict] = []

    # Pass 1: Constant Folding
    lines, steps_cf = constant_folding(lines)

    # Pass 1.5: Common Subexpression Elimination
    lines, steps_cse = common_subexpression_elimination(lines)

    # Pass 2: Dead Code Elimination
    lines, steps_dce = dead_code_elimination(lines)

    # Pass 3: Loop Optimization (LICM)
    lines, steps_loop = loop_optimization(lines)

    all_steps.extend(steps_cf)
    all_steps.extend(steps_cse)
    all_steps.extend(steps_dce)
    all_steps.extend(steps_loop)

    # Count CF sub-techniques
    cf_simple = len([s for s in steps_cf if s['tag'] == 'CF-SIMPLE'])
    cf_mixed = len([s for s in steps_cf if s['tag'] == 'CF-MIXED'])
    cf_multi = len([s for s in steps_cf if s['tag'] == 'CF-MULTI'])
    cf_cond = len([s for s in steps_cf if s['tag'] == 'CF-COND'])
    cf_cp = len([s for s in steps_cf if s['tag'] == 'CP'])
    cf_cse = len(steps_cse)

    # Count DCE sub-techniques
    dce_unreachable = len([s for s in steps_dce if s['tag'] == 'DCE-UCE'])
    dce_unused_var = len([s for s in steps_dce if s['tag'] == 'DCE-UVE'])
    dce_overwritten = len([s for s in steps_dce if s['tag'] == 'DCE-OVE'])
    dce_false_cond = len([s for s in steps_dce if s['tag'] == 'DCE-AFC'])

    # Count Loop sub-techniques
    loop_licm = len([s for s in steps_loop if s['tag'] == 'LICM'])
    loop_sr = len([s for s in steps_loop if s['tag'] == 'LOOP-SR'])
    loop_unroll = len([s for s in steps_loop if s['tag'] == 'LOOP-UNROLL'])

    # Remove trailing newlines from each line for final output
    optimized = ''.join(lines).rstrip('\n')

    # Calculate statistics
    optimized_line_count = len([l for l in optimized.split('\n') if l.strip()])
    original_non_empty = len([l for l in c_code.split('\n') if l.strip()])
    reduction_pct = 0.0
    if original_non_empty > 0:
        reduction_pct = round(
            (1 - optimized_line_count / original_non_empty) * 100, 1
        )

    return {
        "original_code": c_code,
        "optimized_code": optimized,
        "steps": all_steps,
        "summary": {
            "constant_folding": len(steps_cf) + len(steps_cse),
            "cf_simple": cf_simple,
            "cf_mixed": cf_mixed,
            "cf_multi": cf_multi,
            "cf_cond": cf_cond,
            "cf_cp": cf_cp,
            "cf_cse": cf_cse,
            "dead_code_elimination": len(steps_dce),
            "dead_code_unreachable": dce_unreachable,
            "dead_code_unused_var": dce_unused_var,
            "dead_code_overwritten": dce_overwritten,
            "dead_code_false_cond": dce_false_cond,
            "loop_optimization": len(steps_loop),
            "loop_licm": loop_licm,
            "loop_strength_reduction": loop_sr,
            "loop_unrolling": loop_unroll,
            "total": len(all_steps),
            "lines_before": original_non_empty,
            "lines_after": optimized_line_count,
            "reduction_pct": reduction_pct,
        }
    }
