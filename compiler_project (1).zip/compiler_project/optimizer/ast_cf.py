"""
ast_cf.py — AST Constant Folding
"""

from pycparser import c_ast, c_generator
from optimizer.ast_transformer import NodeTransformer

class ConstantFolder(NodeTransformer):
    def __init__(self):
        self.steps = []
        self.generator = c_generator.CGenerator()

    def visit_BinaryOp(self, node):
        # First visit children
        self.generic_visit(node)
        
        # Now check if both children are constants
        if isinstance(node.left, c_ast.Constant) and isinstance(node.right, c_ast.Constant):
            try:
                # We only handle basic types for now
                if node.left.type in ('int', 'float', 'double') and node.right.type in ('int', 'float', 'double'):
                    left_val = float(node.left.value) if 'float' in node.left.type or 'double' in node.left.type else int(node.left.value)
                    right_val = float(node.right.value) if 'float' in node.right.type or 'double' in node.right.type else int(node.right.value)
                    
                    op = node.op
                    result = None
                    if op == '+': result = left_val + right_val
                    elif op == '-': result = left_val - right_val
                    elif op == '*': result = left_val * right_val
                    elif op == '/': 
                        if right_val != 0:
                            if isinstance(left_val, int) and isinstance(right_val, int):
                                result = left_val // right_val
                            else:
                                result = left_val / right_val
                    elif op == '%':
                        if right_val != 0: result = left_val % right_val
                    elif op == '==': result = int(left_val == right_val)
                    elif op == '!=': result = int(left_val != right_val)
                    elif op == '<': result = int(left_val < right_val)
                    elif op == '<=': result = int(left_val <= right_val)
                    elif op == '>': result = int(left_val > right_val)
                    elif op == '>=': result = int(left_val >= right_val)

                    if result is not None:
                        before_code = self.generator.visit(node)
                        
                        # Determine new type
                        new_type = 'int'
                        if isinstance(result, float):
                            new_type = 'double'
                            
                        # Create new node
                        new_node = c_ast.Constant(type=new_type, value=str(result), coord=node.coord)
                        
                        after_code = self.generator.visit(new_node)
                        
                        cf_type = "CF-SIMPLE"
                        if op in ('==', '!=', '<', '<=', '>', '>='):
                            cf_type = "CF-COND"
                            
                        self.steps.append({
                            "line_no": node.coord.line if node.coord else 0,
                            "technique": f"AST Constant Folding ({cf_type})",
                            "tag": cf_type,
                            "color": "purple",
                            "before": before_code,
                            "after": after_code,
                            "explanation": f"Evaluated `{before_code}` into `{after_code}` at compile-time.",
                            "tip": "Exam tip: AST-based constant folding is far more reliable than regex."
                        })
                        
                        return new_node
            except Exception:
                pass
                
        return node
