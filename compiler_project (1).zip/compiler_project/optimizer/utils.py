"""
utils.py — Shared Helper Functions
Used across multiple optimization modules.

Bug fixes applied:
  - Bug 6: find_block_end() now handles braceless single-statement bodies
"""

import re
from typing import List, Optional
from optimizer.expression_evaluator import ExpressionEvaluator


# ══════════════════════════════════════════════════════
#  BLOCK FINDING
# ══════════════════════════════════════════════════════

def find_block_end(lines: List[str], start_idx: int) -> int:
    """
    Find the end of a code block starting at start_idx.
    Handles both braced blocks and single statements (braceless bodies).

    Bug 6 fix: If no opening brace is found on or after the control statement,
    treat the next non-empty line as a single-statement body.
    """
    # First, check if there's a brace on the starting line or nearby
    brace_depth = 0
    found_brace = False

    for i in range(start_idx, len(lines)):
        line = lines[i]
        open_count = line.count('{')
        close_count = line.count('}')

        if open_count > 0:
            found_brace = True

        brace_depth += open_count - close_count

        # If we found a brace and depth returned to 0, this is the end
        if found_brace and brace_depth == 0 and i > start_idx:
            return i
        # Same line: e.g., `if (x) { return 1; }`
        if found_brace and brace_depth == 0 and i == start_idx and open_count > 0:
            return i

    # Bug 6 fix: No braces found — this is a single-statement body
    # (e.g., `if (x > 0)\n    return x;`)
    if not found_brace:
        for i in range(start_idx + 1, len(lines)):
            stripped = lines[i].strip()
            if stripped and not stripped.startswith('//'):
                return i  # The single statement IS the block

    return len(lines) - 1


# ══════════════════════════════════════════════════════
#  VARIABLE READ CHECK
# ══════════════════════════════════════════════════════

def is_variable_read(line: str, var_name: str) -> bool:
    """Check if a variable is read (used) in a line before being written."""
    stripped = line.strip()

    # Check if variable appears in the line
    if not re.search(r'\b' + re.escape(var_name) + r'\b', stripped):
        return False

    # Check if it's on the LHS of a simple assignment (not read)
    # Pattern: var = ... at start of line or after type declaration
    assign_at_start = re.match(
        r'^(?:(?:int|float|double|long|short|unsigned|signed)\s+)?' + re.escape(var_name) + r'\s*=',
        stripped
    )
    if assign_at_start:
        # But check if the RHS also uses the same variable (e.g., x = x + 1)
        assign_full = re.match(
            r'^(?:(?:int|float|double|long|short|unsigned|signed)\s+)?' +
            re.escape(var_name) + r'\s*=\s*(.+)',
            stripped
        )
        if assign_full:
            rhs = assign_full.group(1)
            if re.search(r'\b' + re.escape(var_name) + r'\b', rhs):
                return True  # Variable is read on RHS (e.g., x = x + 1)
        return False

    # If variable appears anywhere else, it's likely being read
    return True


# ══════════════════════════════════════════════════════
#  CONDITION EVALUATION
# ══════════════════════════════════════════════════════

def evaluate_condition(cond_expr: str, evaluator: ExpressionEvaluator) -> Optional[bool]:
    """
    Try to evaluate a condition expression to True/False.
    Returns None if cannot determine at compile time.

    Bug 2 fix (partial): Operator comparison uses correct order
    (check multi-char operators before single-char ones).
    """
    # Handle simple constant comparisons
    # Pattern: num op num
    comp_match = re.match(
        r'(-?\d+\.?\d*)\s*([<>=!]+)\s*(-?\d+\.?\d*)$',
        cond_expr.strip()
    )
    if comp_match:
        left = float(comp_match.group(1))
        op = comp_match.group(2)
        right = float(comp_match.group(3))

        # Bug 2 fix: Check multi-char operators BEFORE single-char ones
        if op == '==':
            return left == right
        elif op == '!=' or op == '<>':
            return left != right
        elif op == '<=':
            return left <= right
        elif op == '>=':
            return left >= right
        elif op == '<':
            return left < right
        elif op == '>':
            return left > right

    # Handle simple numeric constant (0 = false, non-zero = true)
    const_val = evaluator.evaluate(cond_expr)
    if const_val is not None:
        return bool(const_val)

    # Handle true/false literals
    if cond_expr.strip().lower() == 'true':
        return True
    if cond_expr.strip().lower() == 'false':
        return False

    return None
