"""
loop_optimization.py — Loop Optimization Techniques
Sub-techniques:
  - Loop Invariant Code Motion (LICM) — Hoist invariant code above loop
  - Strength Reduction — Replace expensive ops with cheaper ones (mul→shift)
  - Loop Unrolling — Replicate body for small fixed-count loops

Bug fixes applied:
  - Bug 5: LICM hoist uses two-phase approach to avoid index corruption
"""

import re
from typing import List, Tuple, Dict, Set, Optional

from optimizer.expression_evaluator import TokenType, ExpressionEvaluator


# ══════════════════════════════════════════════════════
#  LOOP ANALYZER
# ══════════════════════════════════════════════════════

class LoopAnalyzer:
    """Analyzes loops for invariant code detection."""

    def __init__(self, lines: List[str]):
        self.lines = lines
        self.evaluator = ExpressionEvaluator()

    def extract_variables(self, expr: str) -> Set[str]:
        """Extract all variable names from an expression."""
        tokens = self.evaluator.tokenize(expr)
        variables = set()
        for token in tokens:
            if token.type == TokenType.IDENTIFIER:
                variables.add(token.value)
        return variables

    def find_loop_bounds(self, start_idx: int) -> Optional[Tuple[int, int]]:
        """
        Find the start and end of a loop body.
        Returns (body_start, body_end) or None.
        """
        brace_depth = 0
        body_start = -1

        for i in range(start_idx, len(self.lines)):
            line = self.lines[i]

            if body_start == -1:
                # Looking for opening brace
                if '{' in line:
                    brace_depth = 1
                    body_start = i + 1
                    continue
            else:
                # Inside loop body
                brace_depth += line.count('{') - line.count('}')
                if brace_depth == 0:
                    return (body_start, i - 1)

        return None

    def find_loops(self) -> List[Tuple[int, str, Set[str]]]:
        """
        Find all loops and their iteration variables.
        Returns list of (line_idx, loop_type, loop_variables).
        """
        loops = []

        for i, line in enumerate(self.lines):
            stripped = line.strip()
            loop_vars = set()
            loop_type = None

            # For loop
            for_match = re.search(
                r'for\s*\(\s*(?:int|float|double|long)?\s*(\w+)\s*=\s*[^;]+;',
                stripped
            )
            if for_match:
                loop_type = 'for'
                loop_vars.add(for_match.group(1))
                cond_match = re.search(r';\s*([^;]+)\s*;', stripped)
                if cond_match:
                    cond_vars = self.extract_variables(cond_match.group(1))
                    loop_vars.update(cond_vars)

            # While loop
            while_match = re.search(r'while\s*\(\s*([^)]+)', stripped)
            if while_match:
                loop_type = 'while'
                cond_vars = self.extract_variables(while_match.group(1))
                loop_vars.update(cond_vars)

            # Do-while loop
            do_while_match = re.search(r'do\s*\{', stripped)
            if do_while_match:
                loop_type = 'do-while'
                for j in range(i + 1, min(i + 5, len(self.lines))):
                    dw_match = re.search(r'while\s*\(\s*([^)]+)', self.lines[j])
                    if dw_match:
                        cond_vars = self.extract_variables(dw_match.group(1))
                        loop_vars.update(cond_vars)
                        break

            if loop_type:
                loops.append((i, loop_type, loop_vars))

        return loops

    def is_invariant(self, line: str, loop_vars: Set[str], modified_vars: Set[str]) -> bool:
        """
        Check if a line contains loop-invariant code.
        The LHS being assigned doesn't make the RHS non-invariant.
        What matters is whether the RHS uses loop variables or variables
        that are modified elsewhere in the loop.
        """
        stripped = line.strip()

        # Skip control flow statements
        if not stripped or stripped.startswith('//'):
            return False
        if re.match(r'\{|\}|return|break|continue|if|else|for|while', stripped):
            return False

        # Match assignment pattern
        assign_match = re.match(
            r'^(?:(?:int|float|double|long|short|unsigned|signed)\s+)?(\w+)\s*=\s*([^;]+);?$',
            stripped
        )

        if not assign_match:
            return False

        var_name = assign_match.group(1)
        expr = assign_match.group(2)

        # Check if expression uses any loop variable
        expr_vars = self.extract_variables(expr)
        if expr_vars & loop_vars:
            return False

        # Check if expression uses any variable that is modified IN THE LOOP
        # (excluding the LHS variable itself, which is being assigned by this line)
        other_modified = modified_vars - {var_name}
        if expr_vars & other_modified:
            return False

        return True


# ══════════════════════════════════════════════════════
#  LOOP INVARIANT CODE MOTION (LICM)
# ══════════════════════════════════════════════════════

def loop_optimization(lines: List[str]) -> Tuple[List[str], List[Dict]]:
    """
    Enhanced Loop Invariant Code Motion (LICM):
    - Properly identifies all loop types (for, while, do-while)
    - Tracks all modified variables in the loop
    - Hoists truly invariant code above the loop
    - Preserves semantics by checking dependencies

    Bug 5 fix: Uses two-phase approach for hoisting:
      Phase 1: Collect all hoists with original indices
      Phase 2: Apply hoists in a stable, conflict-free order
    """
    steps = []
    result = list(lines)
    analyzer = LoopAnalyzer(result)
    evaluator = ExpressionEvaluator()

    # Find all loops
    loops = analyzer.find_loops()

    # Process loops from innermost to outermost
    # Bug 5 fix: Collect hoists first, then apply in stable order
    hoists = []  # (loop_idx, hoisted_line, orig_idx, explanation, var_name, expr)

    for loop_idx, loop_type, loop_vars in reversed(loops):
        # Find loop body bounds
        bounds = analyzer.find_loop_bounds(loop_idx)
        if not bounds:
            continue

        body_start, body_end = bounds

        # Find all variables modified in this loop
        modified_vars = set()
        for j in range(body_start, body_end + 1):
            line = result[j]
            # Check for assignments
            assign_match = re.match(
                r'^(?:(?:int|float|double|long|short|unsigned|signed)\s+)?(\w+)\s*=\s*',
                line.strip()
            )
            if assign_match:
                modified_vars.add(assign_match.group(1))
            # Check for increments/decrements
            inc_match = re.findall(r'(\w+)\s*(?:\+\+|\-\-)', line)
            modified_vars.update(inc_match)
            # Check for compound assignments
            compound_match = re.findall(r'(\w+)\s*[+\-*/%]=', line)
            modified_vars.update(compound_match)

        # Find invariant statements
        invariant_lines = []
        for j in range(body_start, body_end + 1):
            line = result[j]
            if analyzer.is_invariant(line, loop_vars, modified_vars):
                invariant_lines.append(j)

        for inv_idx in invariant_lines:
            line = result[inv_idx]
            stripped = line.strip()

            # Get proper indentation from loop line
            loop_line = result[loop_idx]
            indent = len(loop_line) - len(loop_line.lstrip())

            # Create hoisted version
            hoisted_line = ' ' * indent + stripped + '\n'

            # Check if it's a constant expression that can be further folded
            assign_match = re.match(
                r'^(?:(?:int|float|double|long|short|unsigned|signed)\s+)?(\w+)\s*=\s*([^;]+);?$',
                stripped
            )
            if assign_match:
                var_name = assign_match.group(1)
                expr = assign_match.group(2)
                value = evaluator.evaluate(expr)

                if value is not None:
                    formatted = evaluator.format_result(value)
                    explanation = (
                        f"<strong>Loop-Invariant Code Motion:</strong> Expression <code>{expr}</code> produces the same "
                        f"constant value <code>{formatted}</code> in every iteration of the loop.<br><br>"
                        f"<strong>Optimization:</strong> The calculation is moved outside the loop (hoisted), "
                        f"reducing N computations to just 1. This is a classic strength reduction technique."
                    )
                else:
                    explanation = (
                        f"<strong>Invariant Detection:</strong> The expression <code>{stripped}</code> does not depend on "
                        f"any loop variable. Its value remains constant across all iterations.<br><br>"
                        f"<strong>Hoisting:</strong> By moving this code outside the loop, we eliminate redundant "
                        f"computations and potentially enable further constant folding opportunities."
                    )

                hoists.append((loop_idx, hoisted_line, inv_idx, explanation, var_name, expr))

    # Bug 5 fix: Two-phase application
    # Sort hoists by original index (descending) to apply from bottom to top
    # This prevents index shifting issues
    hoists.sort(key=lambda x: x[2], reverse=True)

    applied_hoists = []

    for loop_idx, hoisted_line, orig_idx, explanation, var_name, expr in hoists:
        # Step 1: Remove the original line from the loop body
        original_content = result[orig_idx]
        result.pop(orig_idx)

        # Step 2: Find the correct insertion point
        # After popping, indices >= orig_idx shift down by 1
        # The loop_idx is before orig_idx, so it stays the same
        insert_idx = loop_idx if loop_idx < orig_idx else loop_idx - 1
        result.insert(insert_idx, hoisted_line)

        applied_hoists.append({
            "line_no": loop_idx + 1,
            "technique": "Loop Invariant Code Motion",
            "tag": "LICM",
            "color": "green",
            "before": original_content.strip(),
            "after": f"[Hoisted] {hoisted_line.strip()}",
            "explanation": explanation,
            "tip": "Exam tip: LICM is a fundamental loop optimization that reduces O(N) computations to O(1)."
        })

    # Add steps in correct order (reverse the reversed list)
    applied_hoists.reverse()
    steps.extend(applied_hoists)

    # Sub-technique 2: Strength Reduction
    result, steps_sr = find_strength_reduction(result)
    steps.extend(steps_sr)

    # Sub-technique 3: Loop Unrolling
    result, steps_unroll = find_loop_unrolling(result)
    steps.extend(steps_unroll)

    return result, steps


# ══════════════════════════════════════════════════════
#  LOOP SUB-TECHNIQUE 2: STRENGTH REDUCTION
# ══════════════════════════════════════════════════════

def find_strength_reduction(lines: List[str]) -> Tuple[List[str], List[Dict]]:
    """
    Strength Reduction: Replace expensive operations with cheaper ones in loops.
    Examples:
      - Multiplication by power of 2 → Bit shift
      - Division by power of 2 → Bit shift
      - Modulo by power of 2 → Bitwise AND
    """
    steps = []
    result = list(lines)

    # Find loops and check for strength reduction opportunities
    analyzer = LoopAnalyzer(result)
    loops = analyzer.find_loops()

    for loop_idx, loop_type, loop_vars in loops:
        bounds = analyzer.find_loop_bounds(loop_idx)
        if not bounds:
            continue

        body_start, body_end = bounds

        for j in range(body_start, body_end + 1):
            line = result[j]
            stripped = line.strip()

            # Pattern: x = y * (power of 2)  →  x = y << n
            mul_match = re.search(r'(\w+)\s*\*\s*(\d+)', stripped)
            if mul_match:
                var = mul_match.group(1)
                num = int(mul_match.group(2))
                if num > 0 and (num & (num - 1)) == 0:  # Power of 2
                    shift = num.bit_length() - 1
                    new_expr = f"{var} << {shift}"
                    modified = line.replace(f"{var} * {num}", new_expr)
                    modified = modified.replace(f"{num} * {var}", new_expr)
                    if modified != line:
                        steps.append({
                            "line_no": j + 1,
                            "technique": "Strength Reduction — Multiply to Shift",
                            "tag": "LOOP-SR",
                            "color": "teal",
                            "before": line.rstrip(),
                            "after": modified.rstrip(),
                            "explanation": (
                                f"Multiplication by power of 2 (<code>{num}</code>) replaced with "
                                f"cheaper bit shift <code>{new_expr}</code>. Shift is much faster than multiply!"
                            ),
                            "tip": "Exam tip: Strength reduction replaces expensive ops (mul/div) with cheaper ones (shift)."
                        })
                        result[j] = modified
                        continue

            # Pattern: x = y / (power of 2)  →  x = y >> n
            div_match = re.search(r'(\w+)\s*/\s*(\d+)', stripped)
            if div_match:
                var = div_match.group(1)
                num = int(div_match.group(2))
                if num > 0 and (num & (num - 1)) == 0:  # Power of 2
                    shift = num.bit_length() - 1
                    new_expr = f"{var} >> {shift}"
                    modified = line.replace(f"{var} / {num}", new_expr)
                    if modified != line:
                        steps.append({
                            "line_no": j + 1,
                            "technique": "Strength Reduction — Divide to Shift",
                            "tag": "LOOP-SR",
                            "color": "teal",
                            "before": line.rstrip(),
                            "after": modified.rstrip(),
                            "explanation": (
                                f"Division by power of 2 (<code>{num}</code>) replaced with "
                                f"cheaper bit shift <code>{new_expr}</code>. Shift is much faster than divide!"
                            ),
                            "tip": "Exam tip: Division is expensive; bit shifting is a cheap alternative for powers of 2."
                        })
                        result[j] = modified
                        continue

            # Pattern: x = y % (power of 2)  →  x = y & (num-1)
            mod_match = re.search(r'(\w+)\s*%\s*(\d+)', stripped)
            if mod_match:
                var = mod_match.group(1)
                num = int(mod_match.group(2))
                if num > 0 and (num & (num - 1)) == 0:  # Power of 2
                    mask = num - 1
                    new_expr = f"{var} & {mask}"
                    modified = line.replace(f"{var} % {num}", new_expr)
                    if modified != line:
                        steps.append({
                            "line_no": j + 1,
                            "technique": "Strength Reduction — Modulo to Bitwise AND",
                            "tag": "LOOP-SR",
                            "color": "teal",
                            "before": line.rstrip(),
                            "after": modified.rstrip(),
                            "explanation": (
                                f"Modulo by power of 2 (<code>{num}</code>) replaced with "
                                f"cheaper bitwise AND <code>{new_expr}</code>. AND is much faster than modulo!"
                            ),
                            "tip": "Exam tip: Modulo by power of 2 can use bitwise AND with (divisor-1)."
                        })
                        result[j] = modified

    return result, steps


# ══════════════════════════════════════════════════════
#  LOOP SUB-TECHNIQUE 3: LOOP UNROLLING
# ══════════════════════════════════════════════════════

def find_loop_unrolling(lines: List[str]) -> Tuple[List[str], List[Dict]]:
    """
    Loop Unrolling: Replicate loop body to reduce loop overhead.
    Only suggests unrolling for small fixed-count loops.
    """
    steps = []
    result = list(lines)

    for i, line in enumerate(result):
        stripped = line.strip()

        # Pattern: for (int i = 0; i < N; i++) where N is small constant
        small_loop = re.search(
            r'for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*(\d+)\s*;\s*\1\s*<\s*(\d+)\s*;\s*\1\+\+\s*\)',
            stripped
        )
        if small_loop:
            var = small_loop.group(1)
            start = int(small_loop.group(2))
            end = int(small_loop.group(3))
            iterations = end - start

            # Only suggest for small loops (2-4 iterations)
            if 2 <= iterations <= 4:
                steps.append({
                    "line_no": i + 1,
                    "technique": f"Loop Unrolling — {iterations} iterations",
                    "tag": "LOOP-UNROLL",
                    "color": "blue",
                    "before": line.rstrip(),
                    "after": f"[Suggest: Unroll loop body {iterations} times to reduce overhead]",
                    "explanation": (
                        f"Small loop with {iterations} iterations can be unrolled. "
                        f"Replicate the loop body {iterations} times and remove loop control overhead. "
                        f"This eliminates increment, compare, and jump instructions!"
                    ),
                    "tip": "Exam tip: Loop unrolling reduces overhead by replicating the loop body."
                })

        # Also check for do-while and while with small known bounds
        simple_while = re.search(
            r'while\s*\(\s*(\w+)\s*<\s*(\d+)\s*\)',
            stripped
        )
        if simple_while:
            var = simple_while.group(1)
            bound = int(simple_while.group(2))
            if 2 <= bound <= 4:
                steps.append({
                    "line_no": i + 1,
                    "technique": f"Loop Unrolling — {bound} iterations",
                    "tag": "LOOP-UNROLL",
                    "color": "blue",
                    "before": line.rstrip(),
                    "after": f"[Suggest: Unroll while loop {bound} times]",
                    "explanation": (
                        f"While loop with known bound {bound} can be unrolled. "
                        f"Unrolling reduces loop control overhead."
                    ),
                    "tip": "Exam tip: Unrolling is beneficial for small fixed-iteration loops."
                })

    return result, steps
