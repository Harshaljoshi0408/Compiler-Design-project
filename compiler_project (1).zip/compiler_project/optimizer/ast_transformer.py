"""
ast_transformer.py — Base NodeTransformer for pycparser AST
"""

from pycparser import c_ast

class NodeTransformer(c_ast.NodeVisitor):
    """
    A NodeVisitor subclass that walks the abstract syntax tree and
    allows modification of nodes.
    
    If a visit method returns a new node, it replaces the old node.
    If it returns None, the node is removed.
    """
    def generic_visit(self, node):
        for field in getattr(node, '__slots__', []):
            if field in ('coord', '__weakref__') or field == 'attr_names':
                continue
                
            old_val = getattr(node, field, None)
            
            if isinstance(old_val, list):
                new_list = []
                for item in old_val:
                    if isinstance(item, c_ast.Node):
                        new_item = self.visit(item)
                        if new_item is not None:
                            new_list.append(new_item)
                    else:
                        new_list.append(item)
                setattr(node, field, new_list)
                
            elif isinstance(old_val, c_ast.Node):
                new_node = self.visit(old_val)
                setattr(node, field, new_node)
                
        return node
