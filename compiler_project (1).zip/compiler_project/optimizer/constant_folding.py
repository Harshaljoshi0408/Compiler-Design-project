"""
constant_folding.py — Constant Folding Optimization
Sub-techniques:
  - Simple Expression (basic arithmetic: 3 + 5 → 8)
  - Multiple Constants (array init: {1+1, 2+2} → {2, 4})
  - In Condition (if/while conditions: if (5 > 3) → if (true))
  - Mixed Expression (complex nested: (10 - 3) * 2 → 14)

Bug fixes applied:
  - Bug 1: Skip folding when expression is already a single literal
  - Bug 2: Fix comparison operator order (check <= before <, >= before >)
"""

import re
from typing import List, Tuple, Dict
from optimizer.expression_evaluator import ExpressionEvaluator


def constant_folding(lines: List[str]) -> Tuple[List[str], List[Dict]]:
    """
    Enhanced Constant Folding with sub-techniques:
    - Simple Expression: Basic binary operations
    - Multiple Constants: Array initializers with multiple constants
    - In Condition: Constant folding in if/while conditions
    - Mixed Expression: Complex expressions with parentheses

    Bug 1 fix: Does NOT report single-literal values (e.g., "return 0;",
    "int x = 10;") as optimized — there's nothing to fold.
    """
    steps = []
    result = []
    evaluator = ExpressionEvaluator()

    known_constants: Dict[str, str] = {}

    for i, line in enumerate(lines):
        original_line = line
        modified_line = line
        stripped = line.strip()

        # Phase 0: Constant Propagation
        # Only propagate into RHS of assignments, return statements, and conditions.
        if known_constants and not stripped.startswith('//'):
            cp_changed = False
            
            # Pattern: type var = expr; or var = expr;
            assign_match = re.match(r'^((?:(?:int|float|double|long|short|unsigned|signed)\s+)?\w+\s*=)\s*([^;]+)(;?.*)$', stripped)
            
            if assign_match:
                lhs = assign_match.group(1)
                rhs = assign_match.group(2)
                rest = assign_match.group(3)
                
                new_rhs = rhs
                for var, val in known_constants.items():
                    new_rhs = re.sub(r'\b' + re.escape(var) + r'\b', str(val), new_rhs)
                
                if new_rhs != rhs:
                    new_stripped = f"{lhs} {new_rhs}{rest}"
                    modified_line = line.replace(stripped, new_stripped, 1)
                    cp_changed = True
            
            # Handle return or conditions
            else:
                cond_match = re.search(r'(return\s+|if\s*\(|while\s*\()(.*)', stripped)
                if cond_match:
                    new_line = line
                    for var, val in known_constants.items():
                        new_line = re.sub(r'\b' + re.escape(var) + r'\b', str(val), new_line)
                    
                    if new_line != line:
                        modified_line = new_line
                        cp_changed = True

            if cp_changed:
                steps.append({
                    "line_no": i + 1,
                    "technique": "Constant Propagation",
                    "tag": "CP",
                    "color": "blue",
                    "before": original_line.rstrip(),
                    "after": modified_line.rstrip(),
                    "explanation": "<strong>Constant Propagation:</strong> Substituted known constant values into the expression.<br><br><strong>Impact:</strong> Enables further constant folding.",
                    "tip": "Exam tip: Constant propagation replaces variables with their known constant values."
                })
                line = modified_line
                stripped = line.strip()

        has_fold = False
        cf_type = "CF-SIMPLE"  # default type

        # Pattern 1: Variable declaration with initialization
        var_decl_pattern = re.compile(
            r'((?:int|float|double|long|short|unsigned|signed)\s+(?:\w+\s*,\s*)*\w+)\s*=\s*([^;]+)'
        )

        # Pattern 2: Simple assignment
        assign_pattern = re.compile(r'(\w+)\s*=\s*([^;]+)')

        # Pattern 3: Return statement
        return_pattern = re.compile(r'(return\s+)([^;]+)')

        # Pattern 4: Array initialization
        array_pattern = re.compile(r'(\w+)\s*\[\s*\w*\s*\]\s*=\s*\{([^}]+)\}')

        # Pattern 5: Condition in if/while
        cond_pattern = re.compile(r'(if|while)\s*\(\s*([^)]+)\s*\)')

        processed = False

        # Try condition folding (highest priority)
        match = cond_pattern.search(line)
        if match and not processed:
            cond_expr = match.group(2).strip()
            # Check if it's a comparison that can be folded
            comp_match = re.match(r'(-?\d+\.?\d*)\s*([<>=!]+)\s*(-?\d+\.?\d*)$', cond_expr)
            if comp_match:
                left = float(comp_match.group(1))
                op = comp_match.group(2)
                right = float(comp_match.group(3))

                result_val = None
                # Bug 2 fix: Check multi-char operators BEFORE single-char ones
                if op == '==':
                    result_val = left == right
                elif op == '!=' or op == '<>':
                    result_val = left != right
                elif op == '<=':
                    result_val = left <= right
                elif op == '>=':
                    result_val = left >= right
                elif op == '<':
                    result_val = left < right
                elif op == '>':
                    result_val = left > right

                if result_val is not None:
                    bool_str = 'true' if result_val else 'false'
                    modified_line = line.replace(cond_expr, bool_str, 1)
                    has_fold = True
                    processed = True
                    cf_type = "CF-COND"
                    steps.append({
                        "line_no": i + 1,
                        "technique": "Constant Folding — In Condition",
                        "tag": cf_type,
                        "color": "purple",
                        "before": original_line.rstrip(),
                        "after": modified_line.rstrip(),
                        "explanation": (
                            f"<strong>Compile-Time Evaluation:</strong> The condition <code>{cond_expr}</code> contains only constant values, "
                            f"so the compiler evaluates it to <code>{bool_str}</code> at compile-time.<br><br>"
                            f"<strong>Impact:</strong> This enables dead code elimination — the compiler can now remove unreachable "
                            f"branches, reducing code size and improving execution speed."
                        ),
                        "tip": "Exam tip: Constant folding in conditions is powerful because it enables subsequent dead code elimination, creating a cascade of optimizations."
                    })

        # Try variable declaration
        if not processed:
            match = var_decl_pattern.search(line)
            if match:
                expr = match.group(2).strip()
                value = evaluator.evaluate(expr)
                # Bug 1 fix: Only fold if it's a genuine multi-token expression
                if (value is not None and
                        evaluator.is_pure_constant_expression(expr) and
                        not evaluator._is_single_literal(expr)):
                    formatted = evaluator.format_result(value)
                    modified_line = line.replace(expr, formatted, 1)
                    has_fold = True
                    processed = True
                    # Determine if simple or mixed
                    if any(op in expr for op in ['(', '*', '/']):
                        cf_type = "CF-MIXED"
                        technique_name = "Constant Folding — Mixed Expression"
                        explanation = (
                            f"<strong>Complex Expression Evaluation:</strong> The expression <code>{expr}</code> contains parentheses "
                            f"and multiple operators. The compiler evaluates this entire expression at compile-time, "
                            f"computing <code>{formatted}</code>.<br><br>"
                            f"<strong>Performance Gain:</strong> At runtime, the CPU simply loads the pre-computed value "
                            f"instead of executing multiple arithmetic operations."
                        )
                    else:
                        cf_type = "CF-SIMPLE"
                        technique_name = "Constant Folding — Simple Expression"
                        explanation = (
                            f"<strong>Basic Constant Folding:</strong> Simple arithmetic operation <code>{expr}</code> evaluated "
                            f"at compile-time to produce <code>{formatted}</code>.<br><br>"
                            f"<strong>Why it matters:</strong> The computation moves from runtime (executed every time) "
                            f"to compile-time (executed once), improving program performance."
                        )

                    steps.append({
                        "line_no": i + 1,
                        "technique": technique_name,
                        "tag": cf_type,
                        "color": "purple",
                        "before": original_line.rstrip(),
                        "after": modified_line.rstrip(),
                        "explanation": explanation,
                        "tip": "Exam tip: Constant folding moves computations from runtime to compile-time."
                    })

        # Try simple assignment
        if not processed:
            match = assign_pattern.search(line)
            if match:
                expr = match.group(2).strip()
                value = evaluator.evaluate(expr)
                # Bug 1 fix: Only fold if it's a genuine multi-token expression
                if (value is not None and
                        evaluator.is_pure_constant_expression(expr) and
                        not evaluator._is_single_literal(expr)):
                    formatted = evaluator.format_result(value)
                    modified_line = line.replace(expr, formatted, 1)
                    has_fold = True
                    processed = True
                    if any(op in expr for op in ['(', '*', '/']):
                        cf_type = "CF-MIXED"
                        technique_name = "Constant Folding — Mixed Expression"
                    else:
                        cf_type = "CF-SIMPLE"
                        technique_name = "Constant Folding — Simple Expression"

                    steps.append({
                        "line_no": i + 1,
                        "technique": technique_name,
                        "tag": cf_type,
                        "color": "purple",
                        "before": original_line.rstrip(),
                        "after": modified_line.rstrip(),
                        "explanation": (
                            f"<strong>Assignment Optimization:</strong> The right-hand side expression <code>{expr}</code> is a constant "
                            f"expression that evaluates to <code>{formatted}</code>. The compiler performs this calculation "
                            f"during compilation, not at runtime.<br><br>"
                            f"<strong>Result:</strong> The assignment becomes a simple value load, eliminating arithmetic operations."
                        ),
                        "tip": "Exam tip: Constant folding applies to variable assignments."
                    })

        # Try return statement
        if not processed:
            match = return_pattern.search(line)
            if match:
                expr = match.group(2).strip()
                value = evaluator.evaluate(expr)
                # Bug 1 fix: Only fold if it's a genuine multi-token expression
                if (value is not None and
                        evaluator.is_pure_constant_expression(expr) and
                        not evaluator._is_single_literal(expr)):
                    formatted = evaluator.format_result(value)
                    modified_line = line.replace(expr, formatted, 1)
                    has_fold = True
                    processed = True
                    if any(op in expr for op in ['(', '*', '/']):
                        cf_type = "CF-MIXED"
                        technique_name = "Constant Folding — Mixed Expression"
                    else:
                        cf_type = "CF-SIMPLE"
                        technique_name = "Constant Folding — Simple Expression"

                    steps.append({
                        "line_no": i + 1,
                        "technique": technique_name,
                        "tag": cf_type,
                        "color": "purple",
                        "before": original_line.rstrip(),
                        "after": modified_line.rstrip(),
                        "explanation": (
                            f"Return expression <code>{expr}</code> optimized to <code>{formatted}</code>."
                        ),
                        "tip": "Exam tip: Return statements benefit from constant folding too."
                    })

        # Try array initialization (Multiple Constants)
        if not processed:
            match = array_pattern.search(line)
            if match:
                init_list = match.group(2)
                elements = [e.strip() for e in init_list.split(',')]
                new_elements = []
                changed = False
                for elem in elements:
                    value = evaluator.evaluate(elem)
                    # Bug 1 fix: Only fold if element is not already a single literal
                    if (value is not None and
                            evaluator.is_pure_constant_expression(elem) and
                            not evaluator._is_single_literal(elem)):
                        new_elements.append(evaluator.format_result(value))
                        changed = True
                    else:
                        new_elements.append(elem)

                if changed:
                    new_init = '{' + ', '.join(new_elements) + '}'
                    modified_line = line.replace('{' + init_list + '}', new_init)
                    has_fold = True
                    cf_type = "CF-MULTI"
                    steps.append({
                        "line_no": i + 1,
                        "technique": "Constant Folding — Multiple Constants",
                        "tag": cf_type,
                        "color": "purple",
                        "before": original_line.rstrip(),
                        "after": modified_line.rstrip(),
                        "explanation": (
                            f"<strong>Array Initialization Optimization:</strong> The array initializer contains {len(elements)} elements, "
                            f"with constant expressions that the compiler evaluates at compile-time.<br><br>"
                            f"<strong>Benefit:</strong> At program startup, the array is already populated with final values — "
                            f"no runtime computation needed for initialization."
                        ),
                        "tip": "Exam tip: Array initializers with constants are folded element-by-element."
                    })

        # Update known_constants
        if re.match(r'\{|\}|return|break|continue|goto|if|for|while|switch', stripped):
            known_constants.clear()
        elif not stripped.startswith('//'):
            assign_check = re.match(r'^(?:(?:int|float|double|long|short|unsigned|signed)\s+)?(\w+)\s*=\s*([^;]+);', modified_line.strip())
            if assign_check:
                var_name = assign_check.group(1)
                rhs_val = assign_check.group(2).strip()
                
                if evaluator._is_single_literal(rhs_val):
                    known_constants[var_name] = rhs_val
                else:
                    if var_name in known_constants:
                        del known_constants[var_name]
            
            # Compound assignments and inc/dec invalidate constants
            if re.search(r'(\w+)\s*[+\-*/%]=', modified_line) or re.search(r'(\w+)\s*(?:\+\+|\-\-)', modified_line):
                # For safety, clear all
                known_constants.clear()

        result.append(modified_line)

    return result, steps
