"""
ast_engine.py — AST and CFG Based Optimizer Engine
"""

import re
from typing import Dict, List, Tuple
from pycparser import c_parser, c_ast, c_generator

def pre_process(code: str) -> Tuple[str, List[str]]:
    """
    Strips out #include, comments, and other preprocessor directives because pycparser
    doesn't natively understand them without gcc/cpp.
    """
    # 1. Strip C and C++ style comments
    import re
    # Remove /* ... */
    code = re.sub(r'/\*[\s\S]*?\*/', '', code)
    # Remove // ...
    code = re.sub(r'//.*', '', code)
    
    lines = code.split('\n')
    includes = []
    clean_lines = []
    
    for line in lines:
        if line.strip().startswith('#'):
            includes.append(line)
        else:
            clean_lines.append(line)
            
    # Add fake typedefs for common types that might appear without includes
    fake_typedefs = "typedef int bool;\n"
    
    return fake_typedefs + '\n'.join(clean_lines), includes

def post_process(code: str, includes: List[str]) -> str:
    """
    Adds the #includes back to the generated code.
    Also removes our fake_typedefs.
    """
    # Remove the fake typedef
    lines = code.split('\n')
    clean_lines = [line for line in lines if not line.startswith('typedef int bool;')]
    
    result = []
    result.extend(includes)
    if includes:
        result.append('')
    result.extend(clean_lines)
    return '\n'.join(result)

def run_ast_optimizer(c_code: str) -> Dict:
    """
    The main pipeline for the AST-based optimizer.
    """
    if not c_code or not c_code.strip():
        return {
            "original_code": c_code or "",
            "optimized_code": c_code or "",
            "steps": [],
            "summary": {
                "constant_folding": 0,
                "cf_simple": 0, "cf_mixed": 0, "cf_multi": 0, "cf_cond": 0, "cf_cp": 0, "cf_cse": 0,
                "dead_code_elimination": 0,
                "dead_code_unreachable": 0, "dead_code_unused_var": 0,
                "dead_code_overwritten": 0, "dead_code_false_cond": 0,
                "loop_optimization": 0,
                "loop_licm": 0, "loop_strength_reduction": 0, "loop_unrolling": 0,
                "total": 0,
                "lines_before": 0, "lines_after": 0, "reduction_pct": 0.0,
            }
        }

    # 1. Preprocess
    clean_code, includes = pre_process(c_code)
    
    # 2. Parse AST
    parser = c_parser.CParser()
    try:
        ast = parser.parse(clean_code)
    except Exception as e:
        return {"error": f"Parse Error: {str(e)}"}
        
    steps = []
    
    from optimizer.ast_cf import ConstantFolder
    from optimizer.ast_cp import CPAndCSE
    from optimizer.ast_dce import DeadCodeEliminator
    from optimizer.ast_licm import LICMEliminator
    
    # 1. CP and CSE
    cp = CPAndCSE()
    ast = cp.visit(ast)
    steps.extend(cp.steps)
    
    # 2. Constant Folding
    cf = ConstantFolder()
    ast = cf.visit(ast)
    steps.extend(cf.steps)
    
    # 3. Dead Code Elimination
    dce = DeadCodeEliminator()
    ast = dce.visit(ast)
    steps.extend(dce.steps)
    
    # 4. Loop Optimization (LICM)
    licm = LICMEliminator()
    ast = licm.visit(ast)
    steps.extend(licm.steps)
    
    # 3. Generate Code
    generator = c_generator.CGenerator()
    generated = generator.visit(ast)
    
    # 4. Postprocess
    final_code = post_process(generated, includes)
    
    # Count stats
    original_non_empty = len([l for l in c_code.split('\n') if l.strip()])
    optimized_line_count = len([l for l in final_code.split('\n') if l.strip()])
    reduction_pct = 0.0
    if original_non_empty > 0:
        reduction_pct = round((1 - optimized_line_count / original_non_empty) * 100, 1)

    return {
        "original_code": c_code,
        "optimized_code": final_code,
        "steps": steps,
        "summary": {
            "constant_folding": 0,
            "cf_simple": 0, "cf_mixed": 0, "cf_multi": 0, "cf_cond": 0, "cf_cp": 0, "cf_cse": 0,
            "dead_code_elimination": 0,
            "dead_code_unreachable": 0, "dead_code_unused_var": 0,
            "dead_code_overwritten": 0, "dead_code_false_cond": 0,
            "loop_optimization": 0,
            "loop_licm": 0, "loop_strength_reduction": 0, "loop_unrolling": 0,
            "total": len(steps),
            "lines_before": original_non_empty,
            "lines_after": optimized_line_count,
            "reduction_pct": reduction_pct,
        }
    }
