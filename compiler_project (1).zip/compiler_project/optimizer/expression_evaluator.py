"""
expression_evaluator.py — Tokenizer & Expression Evaluator
Handles parsing and evaluating constant arithmetic expressions in C code.

Bug fixes applied:
  - Bug 7: Handles unary minus (-5, -(3+2))
  - Bug 8: Integer division mode for C semantics (10/3 = 3, not 3.333)
"""

import re
from typing import List, Optional
from dataclasses import dataclass
from enum import Enum


# ══════════════════════════════════════════════════════
#  TOKEN TYPES & TOKEN DATACLASS
# ══════════════════════════════════════════════════════

class TokenType(Enum):
    NUMBER = "NUMBER"
    IDENTIFIER = "IDENTIFIER"
    OPERATOR = "OPERATOR"
    LPAREN = "LPAREN"
    RPAREN = "RPAREN"
    SEMICOLON = "SEMICOLON"
    ASSIGN = "ASSIGN"
    COMMA = "COMMA"
    EOF = "EOF"


@dataclass
class Token:
    type: TokenType
    value: str
    position: int = 0


# ══════════════════════════════════════════════════════
#  EXPRESSION EVALUATOR
# ══════════════════════════════════════════════════════

class ExpressionEvaluator:
    """
    Evaluates arithmetic expressions with support for:
    - Numbers (integers and floats)
    - Operators: +, -, *, /, %
    - Unary minus: -5, -(3+2)
    - Parentheses for grouping
    - Operator precedence
    - C-style integer division (truncation toward zero)
    """

    def __init__(self):
        self.operators = {
            '+': (1, lambda a, b: a + b),
            '-': (1, lambda a, b: a - b),
            '*': (2, lambda a, b: a * b),
            '/': (2, lambda a, b: self._c_divide(a, b)),
            '%': (2, lambda a, b: self._c_modulo(a, b)),
        }

    @staticmethod
    def _c_divide(a, b):
        """C-style division: integer division truncates toward zero."""
        if b == 0:
            return None
        # If both operands are integers, perform integer division
        if isinstance(a, int) and isinstance(b, int):
            # C truncates toward zero: -7/2 = -3 (not -4)
            return int(a / b)
        return a / b

    @staticmethod
    def _c_modulo(a, b):
        """C-style modulo: result has same sign as dividend."""
        if b == 0:
            return None
        if isinstance(a, int) and isinstance(b, int):
            # C modulo: sign follows dividend
            result = abs(a) % abs(b)
            return -result if a < 0 else result
        return a % b

    def tokenize(self, expr: str) -> List[Token]:
        """Convert expression string into tokens."""
        tokens = []
        i = 0
        expr = expr.strip()

        while i < len(expr):
            char = expr[i]

            # Skip whitespace
            if char.isspace():
                i += 1
                continue

            # Numbers (integers and decimals)
            if char.isdigit() or (char == '.' and i + 1 < len(expr) and expr[i + 1].isdigit()):
                num = ""
                while i < len(expr) and (expr[i].isdigit() or expr[i] == '.'):
                    num += expr[i]
                    i += 1
                tokens.append(Token(TokenType.NUMBER, num, i - len(num)))
                continue

            # Operators
            if char in '+-*/%':
                tokens.append(Token(TokenType.OPERATOR, char, i))
                i += 1
                continue

            # Parentheses
            if char == '(':
                tokens.append(Token(TokenType.LPAREN, char, i))
                i += 1
                continue
            if char == ')':
                tokens.append(Token(TokenType.RPAREN, char, i))
                i += 1
                continue

            # Identifiers (variables, function names)
            if char.isalpha() or char == '_':
                ident = ""
                while i < len(expr) and (expr[i].isalnum() or expr[i] == '_'):
                    ident += expr[i]
                    i += 1
                tokens.append(Token(TokenType.IDENTIFIER, ident, i - len(ident)))
                continue

            # Unknown character - skip
            i += 1

        tokens.append(Token(TokenType.EOF, "", i))
        return tokens

    def is_pure_constant_expression(self, expr: str) -> bool:
        """Check if expression contains only numeric constants and operators (no variables)."""
        tokens = self.tokenize(expr)
        for token in tokens:
            if token.type == TokenType.IDENTIFIER:
                return False
        return True

    def _is_single_literal(self, expr: str) -> bool:
        """
        Check if expression is a single numeric literal (no operators).
        This is used to avoid false-positive "folding" of already-folded values.
        Examples: "0" → True, "42" → True, "3.14" → True,
                  "-5" → True (unary minus with literal),
                  "3 + 5" → False
        """
        stripped = expr.strip()
        # Handle optional unary minus
        if stripped.startswith('-'):
            stripped = stripped[1:].strip()
        # Check if remaining is just a number
        if not stripped:
            return False
        try:
            float(stripped)
            return True
        except ValueError:
            return False

    def evaluate(self, expr: str) -> Optional[float]:
        """
        Evaluate a constant expression using shunting yard algorithm.
        Returns None if expression contains variables or is invalid.

        Bug 7 fix: Handles unary minus by converting it to (0 - x).
        Bug 8 fix: Uses C-style integer division.
        """
        if not self.is_pure_constant_expression(expr):
            return None

        tokens = self.tokenize(expr)

        # Handle unary minus: if '-' appears at start or after '(' or after another operator,
        # insert a 0 before it to convert to binary subtraction
        processed_tokens = []
        for idx, token in enumerate(tokens):
            if token.type == TokenType.OPERATOR and token.value == '-':
                # Check if it's unary (at start, after '(' or after another operator)
                if idx == 0:
                    processed_tokens.append(Token(TokenType.NUMBER, "0", token.position))
                elif processed_tokens and processed_tokens[-1].type in (
                    TokenType.LPAREN, TokenType.OPERATOR
                ):
                    processed_tokens.append(Token(TokenType.NUMBER, "0", token.position))
            processed_tokens.append(token)

        tokens = processed_tokens

        output = []
        operators = []

        i = 0
        while i < len(tokens) - 1:  # Exclude EOF
            token = tokens[i]

            if token.type == TokenType.NUMBER:
                if '.' in token.value:
                    output.append(float(token.value))
                else:
                    output.append(int(token.value))

            elif token.type == TokenType.OPERATOR:
                op = token.value
                prec = self.operators[op][0]
                while (operators and operators[-1] in self.operators and
                       self.operators[operators[-1]][0] >= prec):
                    output.append(operators.pop())
                operators.append(op)

            elif token.type == TokenType.LPAREN:
                operators.append(token.value)

            elif token.type == TokenType.RPAREN:
                while operators and operators[-1] != '(':
                    output.append(operators.pop())
                if operators and operators[-1] == '(':
                    operators.pop()

            i += 1

        while operators:
            op = operators.pop()
            if op == '(':
                continue
            output.append(op)

        # Evaluate RPN
        stack = []
        for item in output:
            if isinstance(item, (int, float)):
                stack.append(item)
            elif item in self.operators:
                if len(stack) < 2:
                    return None
                b = stack.pop()
                a = stack.pop()
                result = self.operators[item][1](a, b)
                if result is None:
                    return None
                stack.append(result)

        if len(stack) == 1:
            result = stack[0]
            # Return int if whole number, else rounded float
            if isinstance(result, float) and result.is_integer():
                return int(result)
            return result
        return None

    def format_result(self, value) -> str:
        """Format evaluation result for code insertion."""
        if isinstance(value, float):
            if value.is_integer():
                return str(int(value))
            return str(round(value, 6))
        return str(value)
