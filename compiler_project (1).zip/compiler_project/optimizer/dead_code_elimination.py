"""
dead_code_elimination.py — Dead Code Elimination Optimization
Sub-techniques:
  - Unreachable Code (after return/break/continue/goto/exit)
  - Unused Variables (declared but never read)
  - Overwritten Values (assigned but overwritten before use)
  - Always False Conditions (if/while with compile-time false)

Bug fixes applied:
  - Bug 3: Unused variable detection excludes declaration line from usage scan
  - Bug 4: Overwritten values handles multi-variable declarations properly
"""

import re
from typing import List, Tuple, Dict, Set, Optional
from dataclasses import dataclass, field

from optimizer.expression_evaluator import ExpressionEvaluator
from optimizer.utils import find_block_end, is_variable_read, evaluate_condition


# ══════════════════════════════════════════════════════
#  BLOCK & SCOPE ANALYSIS
# ══════════════════════════════════════════════════════

@dataclass  # dataholder bana deta hai class ko and constructor automatically ban jaat hai
class Block:
    """Represents a code block with scope information."""
    start_line: int     # Block ki start line
    end_line: int = -1  # Block ki end line
    is_dead: bool = False  # Block dead hai ya nahi
    terminator: Optional[str] = None  # Block ka terminator (return, break, continue, etc.)
    brace_depth: int = 0  # Block ka brace depth { and } track krne ke liye
    parent: Optional['Block'] = None  # agr nested block hai toh parent Block ka reference store krega
    children: List['Block'] = field(default_factory=list)  # Block ke children


class ScopeAnalyzer:
    """Analyzes code scope and control flow for DCE."""

    def __init__(self, lines: List[str]):
        self.lines = lines  # input c code line by line list ki form mai store hoga
        self.blocks: List[Block] = []  # ye list future mai blocks store krne ke liye use honge
        self.terminators = {'return', 'break', 'continue', 'goto', 'exit'}  # ye keywords dead code elimination ke liye use honge

    def is_terminator_statement(self, line: str) -> Optional[str]:
        """Check if line is a control flow terminator."""
        stripped = line.strip()

        # Skip comments and empty lines
        if not stripped or stripped.startswith('//'):
            return None

        # Check for return statements
        if re.match(r'return\b', stripped):
            return 'return'

        # Check for break
        if re.match(r'break\s*;?', stripped):
            return 'break'

        # Check for continue
        if re.match(r'continue\s*;?', stripped):
            return 'continue'

        # Check for goto
        match = re.match(r'goto\s+(\w+)\s*;?', stripped)
        if match:
            return f'goto {match.group(1)}'

        # Check for exit/abort calls
        if re.search(r'\b(exit|abort|_exit|ExitProcess)\s*\(', stripped):
            return 'exit'

        return None

    def is_else_or_elseif(self, line: str) -> bool:
        """Check if line starts an else or else-if block."""
        stripped = line.strip()
        return bool(re.match(r'\}\s*else\s*(if\b)?|\belse\s*(if\b)?', stripped))

    def is_block_end(self, line: str) -> bool:
        """Check if line ends a block."""
        stripped = line.strip()
        return stripped == '}' or stripped.startswith('}')

    def find_dead_code_ranges(self) -> List[Tuple[int, int, str]]:
        """
        Find ranges of dead code (start_line, end_line, terminator).
        Returns list of tuples with 0-indexed line numbers.
        """
        dead_ranges = []
        i = 0
        n = len(self.lines)
        brace_depth = 0

        while i < n:
            line = self.lines[i]
            stripped = line.strip()

            # Track brace depth
            brace_depth += line.count('{') - line.count('}')

            # Check for terminator
            terminator = self.is_terminator_statement(line)

            if terminator:
                # Find all consecutive dead lines after terminator
                dead_start = i + 1
                dead_end = i

                j = i + 1
                current_depth = brace_depth

                while j < n:
                    next_line = self.lines[j]
                    next_stripped = next_line.strip()

                    # Update brace depth for this line
                    line_open = next_line.count('{')
                    line_close = next_line.count('}')

                    # Check for else/elseif - this starts live code again
                    if self.is_else_or_elseif(next_line):
                        break

                    # Check if we've exited the current block
                    if current_depth - line_close < brace_depth:
                        break

                    # Skip empty lines and comments in dead zone
                    if next_stripped and not next_stripped.startswith('//'):
                        dead_end = j

                    current_depth += line_open - line_close
                    j += 1

                if dead_end >= dead_start:
                    dead_ranges.append((dead_start, dead_end, terminator))

                i = j
                continue

            i += 1

        return dead_ranges


# ══════════════════════════════════════════════════════
#  DCE SUB-TECHNIQUE 1: UNREACHABLE CODE
# ══════════════════════════════════════════════════════

def find_unreachable_code(lines: List[str]) -> Tuple[List[str], List[Dict]]:
    """
    Find code that is unreachable after terminators (return, break, continue, goto, exit).
    """
    steps = []
    analyzer = ScopeAnalyzer(lines)
    dead_ranges = analyzer.find_dead_code_ranges()

    # Sort ranges by start line (descending) so we can remove from end to start
    dead_ranges.sort(key=lambda x: x[0], reverse=True)

    result = list(lines)

    for start, end, terminator in dead_ranges:
        dead_lines = []
        for idx in range(start, end + 1):
            stripped = result[idx].strip()
            if stripped and not stripped.startswith('//'):
                dead_lines.append(result[idx])

        if dead_lines:
            # Create step for each dead line
            for idx in range(start, end + 1):
                stripped = result[idx].strip()
                if stripped and not stripped.startswith('//'):
                    steps.append({
                        "line_no": idx + 1,
                        "technique": "Unreachable Code Elimination",
                        "tag": "DCE-UCE",
                        "color": "red",
                        "before": result[idx].rstrip(),
                        "after": "    // [REMOVED — Unreachable Code after " + terminator + "]",
                        "explanation": (
                            f"<strong>Unreachable Code:</strong> This line appears after a <code>{terminator}</code> statement "
                            f"and can never be executed. The compiler safely removes it.<br><br>"
                            f"<strong>Impact:</strong> Reduces binary size and eliminates confusion about program flow."
                        ),
                        "tip": "Exam tip: Code after return/break/continue/goto/exit is unreachable and always removed."
                    })

            # Mark dead lines as removed
            for idx in range(start, end + 1):
                stripped = result[idx].strip()
                if stripped and not stripped.startswith('//'):
                    indent = len(result[idx]) - len(result[idx].lstrip())
                    result[idx] = ' ' * indent + "// [REMOVED — Unreachable Code after " + terminator + "]\n"

    return result, steps


# ══════════════════════════════════════════════════════
#  DCE SUB-TECHNIQUE 2: UNUSED VARIABLES
# ══════════════════════════════════════════════════════

def find_unused_variables(lines: List[str]) -> Tuple[List[str], List[Dict]]:
    """
    Find variables that are declared but never read/used.

    Bug 3 fix: The declaration line itself is excluded from usage scanning.
    A variable appearing only on its own declaration line is NOT considered "used".
    """
    steps = []
    result = list(lines)

    # Track variable declarations and usages
    var_declarations: Dict[str, List[Tuple[int, str, Optional[str]]]] = {}  # name -> [(line_idx, type, init_value)]
    var_usages: Set[str] = set()

    # First pass: collect all declarations
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith('//'):
            continue

        # Skip for/while/if control flow lines — variables in loop headers
        # (e.g., `for (int i = 0; ...)`) should NOT be treated as unused declarations
        if re.match(r'\b(for|while|if|switch)\s*\(', stripped):
            continue

        # Match variable declarations: type var; or type var = value;
        decl_pattern = re.compile(
            r'(?:int|float|double|long|short|unsigned|signed|char|bool)\s+(\w+)(?:\s*=\s*([^;]+))?\s*;'
        )
        match = decl_pattern.search(stripped)
        if match:
            var_name = match.group(1)
            init_value = match.group(2)
            if var_name not in var_declarations:
                var_declarations[var_name] = []
            var_declarations[var_name].append((i, 'declaration', init_value))

    # Second pass: check for usages on NON-declaration lines
    # Bug 3 fix: Exclude the declaration line from usage scanning
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith('//'):
            continue

        for var_name in var_declarations:
            # Skip if this is the declaration line for this variable
            decl_lines = {dl[0] for dl in var_declarations[var_name]}
            if i in decl_lines:
                continue

            # Check if variable is used on this line
            if re.search(r'\b' + re.escape(var_name) + r'\b', stripped):
                var_usages.add(var_name)

    # Find unused variables and mark them
    unused_vars = set(var_declarations.keys()) - var_usages

    for var_name in unused_vars:
        for line_idx, decl_type, init_value in var_declarations[var_name]:
            steps.append({
                "line_no": line_idx + 1,
                "technique": "Unused Variable Elimination",
                "tag": "DCE-UVE",
                "color": "orange",
                "before": result[line_idx].rstrip(),
                "after": "    // [REMOVED — Unused Variable: " + var_name + "]",
                "explanation": (
                    f"Variable <code>{var_name}</code> is declared but never used. "
                    f"Dead storage — wasting memory and CPU cycles."
                ),
                "tip": "Exam tip: The compiler removes unused variables — this is a storage optimization."
            })
            indent = len(result[line_idx]) - len(result[line_idx].lstrip())
            result[line_idx] = ' ' * indent + "// [REMOVED — Unused Variable: " + var_name + "]\n"

    return result, steps


# ══════════════════════════════════════════════════════
#  DCE SUB-TECHNIQUE 3: OVERWRITTEN VALUES
# ══════════════════════════════════════════════════════

def find_overwritten_values(lines: List[str]) -> Tuple[List[str], List[Dict]]:
    """
    Find assignments where the value is overwritten before being read.
    Example: x = 5; x = 10; (first assignment is dead)
    """
    steps = []
    result = list(lines)

    # Track variable states
    # For each variable, track the line where it was last assigned but not yet read
    pending_assignment: Dict[str, int] = {}  # var_name -> line_idx

    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith('//'):
            continue

        # Check if this line reads any variables
        for var in list(pending_assignment.keys()):
            # Check if variable is read in this line (before any assignment)
            if is_variable_read(line, var):
                # Variable was read, clear pending
                del pending_assignment[var]

        # Check for new assignment
        assign_match = re.match(
            r'^(?:(?:int|float|double|long|short|unsigned|signed)\s+)?(\w+)\s*=\s*([^;]+);?$',
            stripped
        )
        if assign_match:
            var_name = assign_match.group(1)
            rhs = assign_match.group(2).strip()

            # Check if the RHS reads the same variable (e.g., x = x + 1)
            if re.search(r'\b' + re.escape(var_name) + r'\b', rhs):
                # This reads then writes — clear pending
                if var_name in pending_assignment:
                    del pending_assignment[var_name]
                pending_assignment[var_name] = i
            else:
                # If there's a pending assignment for this variable, it's dead
                if var_name in pending_assignment:
                    dead_line_idx = pending_assignment[var_name]
                    steps.append({
                        "line_no": dead_line_idx + 1,
                        "technique": "Overwritten Value Elimination",
                        "tag": "DCE-OVE",
                        "color": "coral",
                        "before": result[dead_line_idx].rstrip(),
                        "after": "    // [REMOVED — Value Overwritten before Use]",
                        "explanation": (
                            f"Variable <code>{var_name}</code> was assigned a value, "
                            f"but overwritten before being read. First assignment wasted!"
                        ),
                        "tip": "Exam tip: Overwritten values are called 'dead stores' — replaced without being read."
                    })
                    indent = len(result[dead_line_idx]) - len(result[dead_line_idx].lstrip())
                    result[dead_line_idx] = ' ' * indent + "// [REMOVED — Value Overwritten before Use: " + var_name + "]\n"

                # Set this as new pending assignment
                pending_assignment[var_name] = i

        # Check for compound assignments or increment/decrement (these READ then write)
        compound_match = re.findall(r'(\w+)\s*[+\-*/%]=', stripped)
        for var in compound_match:
            if var in pending_assignment:
                del pending_assignment[var]

        incdec_match = re.findall(r'(\w+)\s*(?:\+\+|\-\-)', stripped)
        for var in incdec_match:
            if var in pending_assignment:
                del pending_assignment[var]

        # Clear pending on control flow terminators (they might exit scope)
        if re.match(r'return|break|continue|goto|if|for|while', stripped):
            pending_assignment.clear()

    return result, steps


# ══════════════════════════════════════════════════════
#  DCE SUB-TECHNIQUE 4: ALWAYS FALSE CONDITIONS
# ══════════════════════════════════════════════════════

def find_always_false_conditions(lines: List[str]) -> Tuple[List[str], List[Dict]]:
    """
    Find if/while conditions that are always false and eliminate their dead code blocks.
    Also handles always-true conditions where else block is dead.
    """
    steps = []
    result = list(lines)
    evaluator = ExpressionEvaluator()

    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if not stripped or stripped.startswith('//'):
            i += 1
            continue

        # Check for if or while with condition
        cond_match = re.search(r'(?:if|while)\s*\(\s*([^)]+)\s*\)', stripped)
        if cond_match:
            cond_expr = cond_match.group(1).strip()

            # Try to evaluate the condition
            cond_value = evaluate_condition(cond_expr, evaluator)

            if cond_value is not None:
                if cond_value == False:
                    # Always false - the entire block is dead
                    # Find the block bounds
                    block_start = i
                    block_end = find_block_end(lines, i)

                    if block_end > block_start:
                        for j in range(block_start, block_end + 1):
                            if lines[j].strip() and not lines[j].strip().startswith('//'):
                                steps.append({
                                    "line_no": j + 1,
                                    "technique": "Always-False Condition Elimination",
                                    "tag": "DCE-AFC",
                                    "color": "darkred",
                                    "before": result[j].rstrip(),
                                    "after": "    // [REMOVED — Dead Code (always-false condition)]",
                                    "explanation": (
                                        f"Condition <code>{cond_expr}</code> is always false. "
                                        f"This block's code will never execute — entirely dead code!"
                                    ),
                                    "tip": "Exam tip: Compile-time constant folding can evaluate conditions, then dead blocks are removed."
                                })
                                indent = len(result[j]) - len(result[j].lstrip())
                                result[j] = ' ' * indent + "// [REMOVED — Dead Code (always-false condition: " + cond_expr + ")]\n"

                        i = block_end + 1
                        continue

                elif cond_value == True:
                    # Always true - check for else block which is dead
                    block_end = find_block_end(lines, i)
                    # Look for else after the if block
                    j = block_end + 1
                    if j < len(lines):
                        else_match = re.match(r'\s*\}\s*else\s*(?:\{)?', lines[j])
                        if else_match:
                            # Found else block - it's dead
                            else_block_end = find_block_end(lines, j)
                            for k in range(j, else_block_end + 1):
                                if lines[k].strip() and not lines[k].strip().startswith('//'):
                                    steps.append({
                                        "line_no": k + 1,
                                        "technique": "Always-True Condition Else Elimination",
                                        "tag": "DCE-AFC",
                                        "color": "darkred",
                                        "before": result[k].rstrip(),
                                        "after": "    // [REMOVED — Dead Else (always-true condition)]",
                                        "explanation": (
                                            f"Condition <code>{cond_expr}</code> is always true. "
                                            f"Else block will never execute — dead code!"
                                        ),
                                        "tip": "Exam tip: Always-true conditions make the else block unreachable."
                                    })
                                    indent = len(result[k]) - len(result[k].lstrip())
                                    result[k] = ' ' * indent + "// [REMOVED — Dead Else (always-true: " + cond_expr + ")]\n"

        i += 1

    return result, steps


# ══════════════════════════════════════════════════════
#  MASTER DCE FUNCTION
# ══════════════════════════════════════════════════════

def dead_code_elimination(lines: List[str]) -> Tuple[List[str], List[Dict]]:
    """
    Enhanced Dead Code Elimination with multiple sub-techniques:
    - Unreachable Code (after terminators)
    - Unused Variables (declared but never read)
    - Overwritten Values (assigned but never read before reassign)
    - Always False Conditions (if/while with false constant)
    """
    steps = []
    result = list(lines)

    # Sub-technique 1: Unreachable Code after terminators
    result, steps_unreachable = find_unreachable_code(result)
    steps.extend(steps_unreachable)

    # Sub-technique 2: Unused Variables
    result, steps_unused = find_unused_variables(result)
    steps.extend(steps_unused)

    # Sub-technique 3: Overwritten Values
    result, steps_overwritten = find_overwritten_values(result)
    steps.extend(steps_overwritten)

    # Sub-technique 4: Always False Conditions
    result, steps_false_cond = find_always_false_conditions(result)
    steps.extend(steps_false_cond)

    return result, steps
