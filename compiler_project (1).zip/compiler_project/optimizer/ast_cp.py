"""
ast_cp.py — AST Constant Propagation and Common Subexpression Elimination
"""

from pycparser import c_ast, c_generator
from optimizer.ast_transformer import NodeTransformer

class CPAndCSE(NodeTransformer):
    def __init__(self):
        self.steps = []
        self.generator = c_generator.CGenerator()
        self.known_constants = {}
        self.assigned_exprs = {}

    def clear_state(self):
        self.known_constants.clear()
        self.assigned_exprs.clear()

    def visit_Compound(self, node):
        # We process statements in order
        if node.block_items:
            new_items = []
            for item in node.block_items:
                # Clear state on control flow boundaries
                if isinstance(item, (c_ast.If, c_ast.While, c_ast.For, c_ast.DoWhile, c_ast.Switch, c_ast.Return, c_ast.Break, c_ast.Continue)):
                    self.clear_state()
                    
                new_item = self.visit(item)
                new_items.append(new_item)
                
            node.block_items = new_items
        return node
        
    def visit_If(self, node):
        # Visit condition with current state
        if node.cond:
            node.cond = self.visit(node.cond)
        
        # Clear state before entering branches
        self.clear_state()
        if node.iftrue:
            node.iftrue = self.visit(node.iftrue)
        if node.iffalse:
            node.iffalse = self.visit(node.iffalse)
            
        self.clear_state()
        return node
        
    def visit_While(self, node):
        self.clear_state()
        self.generic_visit(node)
        self.clear_state()
        return node

    def visit_For(self, node):
        self.clear_state()
        self.generic_visit(node)
        self.clear_state()
        return node

    def visit_Assignment(self, node):
        # Visit right side first
        node.rvalue = self.visit(node.rvalue)
        
        if isinstance(node.lvalue, c_ast.ID) and node.op == '=':
            var_name = node.lvalue.name
            
            # Invalidate anything depending on var_name
            to_remove_exprs = []
            for expr_str, v in self.assigned_exprs.items():
                if v == var_name or f" {var_name} " in f" {expr_str} ": # Very rough invalidation
                    to_remove_exprs.append(expr_str)
            for expr_str in to_remove_exprs:
                del self.assigned_exprs[expr_str]
                
            if var_name in self.known_constants:
                del self.known_constants[var_name]

            # Check if right side is a constant
            if isinstance(node.rvalue, c_ast.Constant):
                self.known_constants[var_name] = node.rvalue
            else:
                # CSE logic
                expr_str = self.generator.visit(node.rvalue)
                # If it's a binary op, we can cache it
                if isinstance(node.rvalue, c_ast.BinaryOp):
                    self.assigned_exprs[expr_str] = var_name
                    
        elif node.op != '=':
            # Compound assignment invalidates
            if isinstance(node.lvalue, c_ast.ID):
                self.known_constants.pop(node.lvalue.name, None)
                self.assigned_exprs.clear() # Rough clear
                
        return node
        
    def visit_Decl(self, node):
        if node.init:
            node.init = self.visit(node.init)
            
            if isinstance(node.type, c_ast.TypeDecl) and isinstance(node.type.type, c_ast.IdentifierType):
                var_name = node.name
                
                # Invalidate
                if var_name in self.known_constants:
                    del self.known_constants[var_name]
                    
                if isinstance(node.init, c_ast.Constant):
                    self.known_constants[var_name] = node.init
                elif isinstance(node.init, c_ast.BinaryOp):
                    expr_str = self.generator.visit(node.init)
                    self.assigned_exprs[expr_str] = var_name
                    
        return node

    def visit_ID(self, node):
        # Constant Propagation
        if node.name in self.known_constants:
            const_node = self.known_constants[node.name]
            
            self.steps.append({
                "line_no": node.coord.line if node.coord else 0,
                "technique": "AST Constant Propagation",
                "tag": "CP",
                "color": "blue",
                "before": node.name,
                "after": const_node.value,
                "explanation": f"Replaced variable `{node.name}` with known constant `{const_node.value}`.",
                "tip": "Exam tip: Constant propagation enables deeper constant folding."
            })
            
            return c_ast.Constant(type=const_node.type, value=const_node.value, coord=node.coord)
        return node

    def visit_BinaryOp(self, node):
        # Visit children first
        self.generic_visit(node)
        
        # Check for CSE
        expr_str = self.generator.visit(node)
        if expr_str in self.assigned_exprs:
            cached_var = self.assigned_exprs[expr_str]
            
            self.steps.append({
                "line_no": node.coord.line if node.coord else 0,
                "technique": "AST Common Subexpression Elimination",
                "tag": "CSE",
                "color": "blue",
                "before": expr_str,
                "after": cached_var,
                "explanation": f"Replaced redundant expression `{expr_str}` with previously computed `{cached_var}`.",
                "tip": "Exam tip: CSE reduces redundant operations."
            })
            
            return c_ast.ID(name=cached_var, coord=node.coord)
            
        return node
