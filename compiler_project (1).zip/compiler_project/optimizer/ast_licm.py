"""
ast_licm.py — AST Loop Invariant Code Motion (LICM)
"""

from pycparser import c_ast, c_generator
from optimizer.ast_transformer import NodeTransformer

class ModifiedVariableFinder(c_ast.NodeVisitor):
    def __init__(self):
        self.modified_vars = set()
        
    def visit_Assignment(self, node):
        if isinstance(node.lvalue, c_ast.ID):
            self.modified_vars.add(node.lvalue.name)
        self.generic_visit(node)
        
    def visit_UnaryOp(self, node):
        if node.op in ('p++', '++p', 'p--', '--p') and isinstance(node.expr, c_ast.ID):
            self.modified_vars.add(node.expr.name)
        self.generic_visit(node)
        
class ReadVariableFinder(c_ast.NodeVisitor):
    def __init__(self):
        self.read_vars = set()
        
    def visit_ID(self, node):
        self.read_vars.add(node.name)

class LICMEliminator(NodeTransformer):
    def __init__(self):
        self.steps = []
        self.generator = c_generator.CGenerator()

    def visit_Compound(self, node):
        self.generic_visit(node)
        
        if not node.block_items:
            return node
            
        new_items = []
        for item in node.block_items:
            if isinstance(item, (c_ast.For, c_ast.While, c_ast.DoWhile)):
                # Step 1: Find all modified variables inside the loop
                mod_finder = ModifiedVariableFinder()
                
                loop_body = None
                if isinstance(item, c_ast.For): loop_body = item.stmt
                elif isinstance(item, c_ast.While): loop_body = item.stmt
                elif isinstance(item, c_ast.DoWhile): loop_body = item.stmt
                
                if loop_body:
                    mod_finder.visit(loop_body)
                
                # Also include loop init/cond/next in modified vars for safety
                if isinstance(item, c_ast.For):
                    if item.init: mod_finder.visit(item.init)
                    if item.cond: mod_finder.visit(item.cond)
                    if item.next: mod_finder.visit(item.next)
                elif isinstance(item, c_ast.While):
                    if item.cond: mod_finder.visit(item.cond)
                elif isinstance(item, c_ast.DoWhile):
                    if item.cond: mod_finder.visit(item.cond)

                # Step 2: Extract invariant code
                invariants = []
                
                class LoopBodyTransformer(NodeTransformer):
                    def __init__(self, parent_licm, modified_vars):
                        self.parent = parent_licm
                        self.modified_vars = modified_vars
                        self.invariants = []
                        
                    def visit_Assignment(self, n):
                        # check if right side only reads unmodified vars
                        read_finder = ReadVariableFinder()
                        read_finder.visit(n.rvalue)
                        
                        is_invariant = True
                        for rv in read_finder.read_vars:
                            if rv in self.modified_vars:
                                is_invariant = False
                                break
                                
                        if is_invariant and isinstance(n.lvalue, c_ast.ID):
                            # The assigned variable itself becomes modified? Yes, but it's invariant!
                            # For simplicity, if it's purely invariant, we hoist it.
                            before_code = self.parent.generator.visit(n)
                            
                            self.parent.steps.append({
                                "line_no": n.coord.line if n.coord else 0,
                                "technique": "AST Loop Invariant Code Motion",
                                "tag": "LICM",
                                "color": "green",
                                "before": before_code,
                                "after": "// Hoisted outside loop",
                                "explanation": f"`{before_code}` does not change inside the loop. It was moved outside.",
                                "tip": "Exam tip: LICM reduces instructions executed per loop iteration."
                            })
                            
                            self.invariants.append(n)
                            return c_ast.EmptyStatement() # Remove from loop
                            
                        return n
                        
                    def visit_Decl(self, n):
                        if n.init:
                            read_finder = ReadVariableFinder()
                            read_finder.visit(n.init)
                            is_invariant = True
                            for rv in read_finder.read_vars:
                                if rv in self.modified_vars:
                                    is_invariant = False
                                    break
                            if is_invariant:
                                before_code = self.parent.generator.visit(n)
                                self.parent.steps.append({
                                    "line_no": n.coord.line if n.coord else 0,
                                    "technique": "AST Loop Invariant Code Motion",
                                    "tag": "LICM",
                                    "color": "green",
                                    "before": before_code,
                                    "after": "// Hoisted outside loop",
                                    "explanation": f"`{before_code}` does not change inside the loop. It was moved outside.",
                                    "tip": "Exam tip: Declarations with constant right sides can be hoisted."
                                })
                                self.invariants.append(n)
                                return c_ast.EmptyStatement()
                        return n

                if loop_body:
                    body_transformer = LoopBodyTransformer(self, mod_finder.modified_vars)
                    new_body = body_transformer.visit(loop_body)
                    invariants = body_transformer.invariants
                    
                    if isinstance(item, c_ast.For): item.stmt = new_body
                    elif isinstance(item, c_ast.While): item.stmt = new_body
                    elif isinstance(item, c_ast.DoWhile): item.stmt = new_body
                    
                # Insert invariants BEFORE the loop
                new_items.extend(invariants)
                new_items.append(item)
            else:
                new_items.append(item)
                
        node.block_items = new_items
        return node
