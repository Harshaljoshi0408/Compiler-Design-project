"""
common_subexpr_elimination.py — Common Subexpression Elimination (CSE)
"""

import re
from typing import List, Tuple, Dict

def common_subexpression_elimination(lines: List[str]) -> Tuple[List[str], List[Dict]]:
    """
    Common Subexpression Elimination (CSE):
    Finds identical expressions computed multiple times and replaces them
    with a reference to a previously computed variable.
    """
    steps = []
    result = []
    
    # Map from RHS expression string -> LHS variable name that holds it
    assigned_exprs: Dict[str, str] = {}
    
    for i, line in enumerate(lines):
        original_line = line
        modified_line = line
        stripped = line.strip()

        # Skip comments
        if stripped.startswith('//'):
            result.append(line)
            continue

        # Clear state on control flow or scope changes
        if re.match(r'\{|\}|return|break|continue|goto|if|for|while|switch', stripped):
            assigned_exprs.clear()
            result.append(line)
            continue

        # Check for assignment
        assign_match = re.match(r'^((?:(?:int|float|double|long|short|unsigned|signed)\s+)?(\w+)\s*=)\s*([^;]+)(;?.*)$', stripped)
        
        cse_applied = False
        
        if assign_match:
            lhs_part = assign_match.group(1)
            var_name = assign_match.group(2)
            rhs_expr = assign_match.group(3).strip()
            rest = assign_match.group(4)
            
            # 1. Check if RHS is a known expression
            # To be safe, only replace if it's a binary expression with variables, e.g. a + b, not single literals.
            # We don't want to replace `x = 5` with `x = y` just because `y = 5`.
            is_complex = bool(re.search(r'[+\-*/%<>=!&|]', rhs_expr))
            
            if is_complex and rhs_expr in assigned_exprs:
                prev_var = assigned_exprs[rhs_expr]
                
                # Make sure we don't do something like x = x (self assignment)
                if prev_var != var_name:
                    new_stripped = f"{lhs_part} {prev_var}{rest}"
                    modified_line = line.replace(stripped, new_stripped, 1)
                    cse_applied = True
                    
                    steps.append({
                        "line_no": i + 1,
                        "technique": "Common Subexpression Elimination",
                        "tag": "CSE",
                        "color": "blue",
                        "before": original_line.rstrip(),
                        "after": modified_line.rstrip(),
                        "explanation": f"<strong>Common Subexpression Elimination:</strong> The expression <code>{rhs_expr}</code> was previously computed and stored in <code>{prev_var}</code>. Instead of recomputing it, we reuse the existing value.<br><br><strong>Impact:</strong> Saves CPU cycles by eliminating redundant calculations.",
                        "tip": "Exam tip: CSE identifies redundant computations and reuses previously computed values."
                    })
                    line = modified_line
            
            # 2. Handle variable modification (invalidation) FIRST
            # If a variable is modified, any expression containing it is no longer valid.
            to_remove = []
            for expr, cached_var in assigned_exprs.items():
                # If the variable we just modified is part of a cached expression (as a whole word)
                # Or if we overwrote the cached_var itself
                if cached_var == var_name or re.search(r'\b' + re.escape(var_name) + r'\b', expr):
                    to_remove.append(expr)
            
            for expr in to_remove:
                del assigned_exprs[expr]

            # 3. Add current expression to known expressions
            # But only if we didn't just apply CSE, it's complex enough,
            # and the assigned variable is NOT part of the expression (e.g. avoid x = x + 1)
            if not cse_applied and is_complex and not re.search(r'\b' + re.escape(var_name) + r'\b', rhs_expr):
                assigned_exprs[rhs_expr] = var_name

        # Invalidate on compound assignments and inc/dec
        if re.search(r'(\w+)\s*[+\-*/%]=', modified_line) or re.search(r'(\w+)\s*(?:\+\+|\-\-)', modified_line):
            assigned_exprs.clear()

        result.append(modified_line)

    return result, steps
