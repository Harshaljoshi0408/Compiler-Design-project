# C Code Optimizer — Compiler Design Project

**Techniques:** Constant Folding | Dead Code Elimination | Loop LICM

## Project Structure

```
Compiler Design Project/
├── app.py                  ← Flask server & routes
├── optimizer_engine.py     ← Core optimization logic (CF, DCE, LICM)
├── requirements.txt        ← Python dependencies
├── templates/
│   └── index.html          ← HTML template (Jinja2)
└── static/
    ├── css/
    │   └── style.css       ← All CSS styles
    └── js/
        └── main.js         ← All JavaScript logic
```

## How to Run

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Start server
python app.py

# 3. Open browser
http://127.0.0.1:5000
```

## Optimization Techniques

| Tag | Technique | Description |
|-----|-----------|-------------|
| `CF` | Constant Folding | Compile-time pe `3+5` → `8` evaluate karna |
| `DCE` | Dead Code Elimination | `return` ke baad wala code remove karna |
| `LICM` | Loop Invariant Code Motion | Loop ke bahar invariant code hoist karna |
